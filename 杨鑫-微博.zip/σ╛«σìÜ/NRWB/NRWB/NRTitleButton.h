//
//  NRTitleButton.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/7.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

//标题按钮
@interface NRTitleButton : UIButton

@end
