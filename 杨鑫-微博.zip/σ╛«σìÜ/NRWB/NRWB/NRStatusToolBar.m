//
//  NRStatusToolBar.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/13.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRStatusToolBar.h"
#import "NRComposeViewController.h"

@interface NRStatusToolBar ()
/** 存放所有的按钮 */
@property(nonatomic, strong) NSMutableArray *btns;

/** 存放分割线 */
@property(nonatomic, strong) NSMutableArray *dividers;

@property(nonatomic, strong) UIButton *repostBtn;
@property(nonatomic, strong) UIButton *commentBtn;
@property(nonatomic, strong) UIButton *attitudeBtn;
@end


@implementation NRStatusToolBar

- (NSMutableArray *)btns{
    if (!_btns) {
        _btns = [NSMutableArray array];
    }
    return _btns;
}

- (NSMutableArray *)dividers{
    if (!_dividers) {
        _dividers = [NSMutableArray array];
    }
    return _dividers;
}

+ (instancetype)toolBar{
    return [self new];
}

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_card_bottom_background"]];
        self.repostBtn =  [self setupBtnWithTitle:@"转发" iconName:@"timeline_icon_retweet" buttonType:NRStatusToolBarButtonTypeZhuanFa];
        self.commentBtn = [self setupBtnWithTitle:@"评论" iconName:@"timeline_icon_comment" buttonType:NRStatusToolBarButtonTypePingLun];
        self.attitudeBtn = [self setupBtnWithTitle:@"点赞" iconName:@"timeline_icon_unlike" buttonType:NRStatusToolBarButtonTypeDianZan];
        
        //添加分割线
        [self setupDivider];
        [self setupDivider];
    }
    return self;
}

/**
 * 添加分割线
 */
- (void)setupDivider
{
    UIImageView *divider = [[UIImageView alloc] init];
    divider.image = [UIImage imageNamed:@"timeline_card_bottom_line"];
    [self addSubview:divider];
    
    [self.dividers addObject:divider];
}


- (UIButton *)setupBtnWithTitle:(NSString *)title iconName:(NSString *)iconName buttonType:(NRStatusToolBarButtonType)type{
    UIButton *btn = [UIButton new];
    btn.tag = type;
    [btn setImage:[UIImage imageNamed:iconName] forState:UIControlStateNormal];
    btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0) ;
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"timeline_card_bottom_background_highlighted"] forState:UIControlStateHighlighted];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    [self addSubview:btn];
    
    [self.btns addObject:btn];
    
    //按钮的点击方法
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    return btn;
    

}

/** 评论按钮的点击 */
- (void)btnClick:(UIButton *)btn{
    
    switch (btn.tag) {
        case NRStatusToolBarButtonTypeZhuanFa:{
            //发通知
            NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
            userInfo[NRStatusBtnkey] = self.status;
            [NRNotificationCenter postNotificationName:NRStatusBtnDidSelectedNotification object:nil userInfo:userInfo];

            break;
        }
        case NRStatusToolBarButtonTypePingLun:{
            //发通知
            NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
            userInfo[NRStatusBtnPingLunkey] = self.status;
            [NRNotificationCenter postNotificationName:NRStatusBtnPingLunNotification object:nil userInfo:userInfo];
            break;
        }
            
        default:
            break;
    }
    
    
//    [NRNotificationCenter postNotificationName:NRStatusBtnDidSelectedNotification object:self.status];

}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    NSInteger count = self.btns.count;
    CGFloat btnW = self.width/count;
    CGFloat btnH = self.height;
    for (int i = 0; i < count; i++) {
        UIButton *btn = self.btns[i];
        btn.y = 0;
        btn.width = btnW;
        btn.x = i * btnW;
        btn.height = btnH;
    }
    
    // // 设置分割线的frame
    NSInteger dividerCount = self.dividers.count;
    for (int i = 0; i<dividerCount; i++) {
        UIImageView *divider = self.dividers[i];
        divider.width = 1;
        divider.height = btnH;
        divider.x = (i + 1) * btnW;
        divider.y = 0;
    }

}

- (void)setStatus:(NRWBStatus *)status{
    _status = status;
    
    //转发
    [self setupBtnCount:status.reposts_count Title:@"转发" btn:self.repostBtn];
    
    //评论
    [self setupBtnCount:status.comments_count Title:@"评论" btn:self.commentBtn];

    //赞
    [self setupBtnCount:status.attitudes_count Title:@"点赞" btn:self.attitudeBtn];


   

}

- (void)setupBtnCount:(NSInteger)count Title:(NSString *)title btn:(UIButton *)btn{
    if (count) {
        if (count < 10000) {
            title = [NSString stringWithFormat:@"%ld",count];
        }else{
            CGFloat countWan = count/10000.0;
            title = [NSString stringWithFormat:@"%.1f万",countWan];
            title = [title stringByReplacingOccurrencesOfString:@".0" withString:@""];
        }
    }
    [btn setTitle:title forState:UIControlStateNormal];
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
