//
//  NRComposePhotosView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/18.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NRComposePhotosView : UIView

- (void)addPhoto:(UIImage *)photo;
//- (NSArray *)photos;

@property(nonatomic, strong, readonly) NSMutableArray *photos;
@end
