//
//  NRWBTabBarController.m
//  微博R
//
//  Created by apple-jd42 on 15/10/30.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBTabBarController.h"
#import "NRTabBar.h"
#import "NRComposeViewController.h"


@interface NRWBTabBarController () <NRTabBarDelegate>

@end

@implementation NRWBTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //初始化自控制器
    
    //3.设置子控制器
    NRWHomeTableViewController *homeVC = [NRWHomeTableViewController new];
    [self addChildVC:homeVC title:@"主页" image:@"tabbar_home" selectedimage:@"tabbar_home_selected"];
    
    NRWBMessageCenterTableViewController *messageVC = [NRWBMessageCenterTableViewController new];
    [self addChildVC:messageVC title:@"消息" image:@"tabbar_message_center_selected" selectedimage:@"tabbar_message_center_selected"];
    
    NRWBDiscoverTableViewController *discoverVC = [NRWBDiscoverTableViewController new];
    [self addChildVC:discoverVC title:@"发现" image:@"tabbar_discover" selectedimage:@"tabbar_discover_selected"];
    
    NRWBProfileTableViewController *profileVC = [[NRWBProfileTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self addChildVC:profileVC title:@"我" image:@"tabbar_profile" selectedimage:@"tabbar_profile_selected"];
    
    NRTabBar *tabBar =  [NRTabBar new];
    //tabBar.delegate = self;
    
    [self setValue:tabBar forKey:@"tabBar"];

}


//将相同的代码放到一个方法中，不同的东西做参数，在使用这段代码的地方调用方法，传递参数
/**
 *  添加一个自控制器
 *
 *  @param childVC       自控器的类型
 *  @param title         标题
 *  @param image         图片
 *  @param selectedImage 选中时候的图片
 */
- (void)addChildVC:(UIViewController *)childVC title:(NSString *)title image:(NSString *)image selectedimage:(NSString *)selectedImage{
    //设置自控器的标题图片
    childVC.title = title;
   // childVC.view.backgroundColor = NRWRandomColor;
    childVC.tabBarItem.title = title;
    childVC.tabBarItem.image = [UIImage imageNamed:image];
    childVC.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //设置文字的样式
    //正常情况下的样式
    NSMutableDictionary *textAtts = [NSMutableDictionary dictionary];
    textAtts[NSForegroundColorAttributeName] = NRWColor(123, 123, 123);
    
    //选中情况下的样式
    NSMutableDictionary *selectTextAtts = [NSMutableDictionary dictionary];
    selectTextAtts[NSForegroundColorAttributeName] = [UIColor orangeColor];
    
    [childVC.tabBarItem setTitleTextAttributes:textAtts forState:UIControlStateNormal];
    selectTextAtts[NSForegroundColorAttributeName] = [UIColor orangeColor];
    [childVC.tabBarItem setTitleTextAttributes:selectTextAtts forState:UIControlStateHighlighted];
    
    //先添加一个导航控制器
    NRWBNavigationController *navc = [[NRWBNavigationController alloc] initWithRootViewController:childVC];
    
    //添加自控器
    [self addChildViewController:navc];
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - NRTabBatDelegate
- (void)tabBarDidClickPlushButton:(NRTabBar *)tabBar{
    NRComposeViewController *compose = [NRComposeViewController new];
    NRWBNavigationController *navi = [[NRWBNavigationController alloc] initWithRootViewController:compose];
    [self presentViewController:navi animated:YES completion:nil];
}

@end
