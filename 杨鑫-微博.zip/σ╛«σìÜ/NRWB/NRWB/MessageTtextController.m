//
//  MessageTtextController.m
//  微博R
//
//  Created by apple-jd42 on 15/10/31.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "MessageTtextController.h"
#import "MessageText2Controller.h"

@interface MessageTtextController ()

@end

@implementation MessageTtextController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    MessageText2Controller *text2VC = [MessageText2Controller new];
    text2VC.title = @"测试2控制器";
    [self.navigationController pushViewController:text2VC animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
