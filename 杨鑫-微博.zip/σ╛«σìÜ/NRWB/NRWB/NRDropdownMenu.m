//
//  NRDropdownMenu.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/2.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRDropdownMenu.h"

@interface NRDropdownMenu()
@property(nonatomic, strong) UIImageView *containerView;
@end


@implementation NRDropdownMenu

- (UIImageView *)containerView{
    if (!_containerView) {
        //添加灰色图片控件
        UIImageView *containerView = [UIImageView new];
        containerView.image = [UIImage imageNamed:@"popover_background"];
//        containerView.width = 200;
//        containerView.height = 300;
        self.containerView = containerView;
        //[self.view.window addSubview:dropdownMenu];
        containerView.userInteractionEnabled = YES;//开启和用户交互功能
        [self addSubview:containerView];
    }
    
    return _containerView;
}
- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //清除颜色
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}

+ (instancetype)menu{
    return [self new];
}

- (void)showFromView:(UIView *)fromView{
    //获得最上面的窗口
    UIWindow *window = [UIApplication sharedApplication].windows.lastObject;
    
    //添加自己到窗口上面
    [window addSubview:self];
    
    //设置尺寸
    self.frame = window.bounds;
    
    //调整灰色图片的位置
    //默认情况下，frame是以父控件左上角的坐标系做为原点的
    //转换坐标系
    CGRect newFrame = [fromView convertRect:fromView.bounds toView:window];
    self.containerView.centerX = CGRectGetMidX(newFrame);
    self.containerView.y = CGRectGetMaxY(newFrame);
    
    //通知外界自己被显示
    if ([self.delegate respondsToSelector:@selector(dropdownMenuDidShow:)]) {
        [self.delegate dropdownMenuDidShow:self];
    }
    
}

//销魂下拉菜单
- (void)dismiss{
    [self removeFromSuperview];
    
    //通知别人自己被销毁
    if ([self.delegate respondsToSelector:@selector(dropdownMenuDidDismiss:)]) {
        [self.delegate dropdownMenuDidDismiss:self];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dismiss];
}

- (void)setContent:(UIView *)content{
    //调整位置
    content.x = 10;
    content.y = 15;
    
    //调整内容的位置
   // content.width = self.containerView.width - 2 * content.x;
    //设置菜单的高度
    self.containerView.height = CGRectGetMaxY(content.frame) + 10;
    self.containerView.width = CGRectGetMaxX(content.frame) + 10;
    _content = content;
    [self.containerView addSubview:content];
}

- (void)setContentController:(UIViewController *)contentController{
    _contentController = contentController;
    self.content = contentController.view;
}
@end
