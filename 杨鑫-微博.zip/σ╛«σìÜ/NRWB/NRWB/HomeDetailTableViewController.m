//
//  HomeDetailTableViewController.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/23.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "HomeDetailTableViewController.h"
#import "NRStatusCell.h"
#import "NRWBAccountTool.h"

@interface HomeDetailTableViewController ()

@end

@implementation HomeDetailTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"微博正文";
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self.tableView registerClass:[NRStatusCell class] forCellReuseIdentifier:@"Cell"];
    NSLog(@"----%@", self.statusFrame.status.idstr);
    //[self getPingLunNumber];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/** 获取评论数和转发数 */
- (void)getPingLunNumber{
    //[super send];
    //转发微博的URL：https://api.weibo.com/2/statuses/count.json
    //参数
    // access_token	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
    //  comment	true	string	评论内容，必须做URLencode，内容不超过140个汉字。
    //id	true	int64	需要评论的微博ID。
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [NRWBAccountTool account].access_token;
    params[@"id"] = self.statusFrame.status.idstr;
    
    //只能发有文字的微博
    // 3.发送请求
    [mgr POST:@"https://api.weibo.com/2/statuses/count.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        NSLog(@"responseObject%@", responseObject);
        [MBProgressHUD showSuccess:@"获取评论成功"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"获取评论失败"];
    }];

}




#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    if (section == 1) {
        return 2;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NRStatusCell *cell = [NRStatusCell cellWithTableView:tableView];
        //给cell传递模型数据
        cell.statusFrame = self.statusFrame;
        cell.toolBar.hidden = YES;
        return cell;
    }
    static NSString *ID = @"status";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
    }

    

   return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return self.statusFrame.cellHeight;
    }
    return 50;
}

@end
