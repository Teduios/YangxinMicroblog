//
//  NRWBStatusPhotoView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/14.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#define NRStatusPhotoMargin 10
#define NRStatusPhotoWH     80
@interface NRWBStatusPhotoView : UIView
@property(nonatomic, strong) NSArray *photos;

//根据图片个数计算相册的尺寸
+ (CGSize)SizeWithCount:(NSInteger)count;
@end
