//
//  NREmotion.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotion.h"
#import "MJExtension.h"

@interface NREmotion() <NSCoding>
@end

@implementation NREmotion

MJCodingImplementation

////从文件中解析对象时调用
//- (instancetype)initWithCoder:(NSCoder *)aDecoder{
//    if (self = [super init]) {
////        self.chs = [aDecoder decodeObjectForKey:@"chs"];
////        self.png = [aDecoder decodeObjectForKey:@"png"];
////        self.code = [aDecoder decodeObjectForKey:@"code"];
//        [self enumerateIvarsWithBlock:^(MJIvar *ivar, BOOL *stop) {
//            ivar.value = [aDecoder decodeObjectForKey:@"ivar.name"];
//        }];
//    }
//    return self;
//}
//
////将对象写入文件
//- (void)encodeWithCoder:(NSCoder *)aCoder{
////    [aCoder encodeObject:self.chs forKey:@"chs"];
////    [aCoder encodeObject:self.png forKey:@"png"];
////    [aCoder encodeObject:self.code forKey:@"code"];
//}

@end
