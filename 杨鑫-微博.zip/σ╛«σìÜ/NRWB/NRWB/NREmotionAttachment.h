//
//  NREmotionAttachment.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/21.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NREmotion.h"

@interface NREmotionAttachment : NSTextAttachment
@property(nonatomic, strong) NREmotion *emotion;
@end
