//
//  NREmotionalListView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionalListView.h"
#import "NREmotionPageView.h"


@interface NREmotionalListView() <UIScrollViewDelegate>
@property (nonatomic, weak) UIScrollView *scrollView;
@property (nonatomic, weak) UIPageControl *pageControl;
@end

@implementation NREmotionalListView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        //1.scrollView
        UIScrollView *scrollView = [[UIScrollView alloc] init];
        scrollView.delegate = self;
        
        //scrollView.backgroundColor = [UIColor redColor];
        scrollView.pagingEnabled = YES;
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.showsVerticalScrollIndicator = NO;
        [self addSubview:scrollView];
        self.scrollView = scrollView;
       
        
        //PageControl
       UIPageControl *pageControl = [[UIPageControl alloc] init];
        pageControl.userInteractionEnabled = NO;
        
        //当页数只有1页的时候,自动隐藏pageControl
        pageControl.hidesForSinglePage = YES;
        
        [self addSubview:pageControl];
        
        //设置圆点的图片
        [pageControl setValue:[UIImage imageNamed:@"compose_keyboard_dot_normal"] forKeyPath:@"pageImage"];
        [pageControl setValue:[UIImage imageNamed:@"compose_keyboard_dot_selected"] forKeyPath:@"currentPageImage"];
        
        self.pageControl = pageControl;
        
       
    }
    return self;
}

- (void)setEmotions:(NSArray *)emotions{
    _emotions = emotions;
    
//    //设置页数
    NSInteger count = (emotions.count + NREmotionPageSize - 1)/NREmotionPageSize;
    //self.pageControl.numberOfPages = count>1?count:0;
    self.pageControl.numberOfPages = count;
  
    //2.用来设置每一页的表情空间
    for (int i = 0; i < count; i++) {
        NREmotionPageView *pageView = [NREmotionPageView new];
        //pageView.backgroundColor = NRWRandomColor;
        
        //计算表情范围
        NSRange rang;
        rang.location = i * NREmotionPageSize;
        
        //剩余的表情数
        NSInteger leftEmotion = emotions.count - rang.location;
        if (leftEmotion >= NREmotionPageSize) {
            rang.length = NREmotionPageSize;
        }else{
            rang.length = leftEmotion;
        }
        
        
        //设置这一页的表情
        pageView.emotions = [emotions subarrayWithRange:rang];
        [self.scrollView addSubview:pageView];
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
        //1.pageControl
        self.pageControl.width = self.width;
        self.pageControl.height = 24;
        self.pageControl.x = 0;
        self.pageControl.y = self.height - self.pageControl.height;
    
        //2.scrollView
        self.scrollView.width = self.width;
        self.scrollView.height = self.pageControl.y;
        self.scrollView.x = 0;
        self.scrollView.y = 0;
    
    //3.设置scrollView内部没一页的尺寸
    NSInteger count = self.scrollView.subviews.count;
    for (int i = 0; i < count; i++) {
        UIView *pageView = self.scrollView.subviews[i];
        pageView.x = pageView.width * i;
        pageView.y = 0;
        pageView.width = self.scrollView.width;
        pageView.height = self.scrollView.height;
    }
    
    //4.scrollView的滚动范围
     self.scrollView.contentSize = CGSizeMake(count * self.scrollView.width, 0);

}

#pragma mark - UIscrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    double pageNo = scrollView.contentOffset.x / scrollView.width;
    self.pageControl.currentPage = round(pageNo);
}
@end
