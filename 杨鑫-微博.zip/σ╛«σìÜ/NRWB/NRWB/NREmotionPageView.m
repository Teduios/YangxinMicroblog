//
//  NREmotionPageView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionPageView.h"
#import "NREmotion.h"
#import "NREmotionPopView.h"
#import "NREmotionButton.h"
#import "NREmotionTool.h"

@interface NREmotionPageView ()
/** 点击表情按钮后弹出的放大镜 */
@property(nonatomic, strong) NREmotionPopView *popView;

/** 删除按钮 */
@property(nonatomic, weak) UIButton *deleteBtn;

@end


@implementation NREmotionPageView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //删除按钮
        UIButton *deleteBtn = [UIButton new];
        [deleteBtn setImage:[UIImage imageNamed:@"compose_emotion_delete"] forState:UIControlStateNormal];
         [deleteBtn setImage:[UIImage imageNamed:@"compose_emotion_delete_highlighted"] forState:UIControlStateHighlighted];
        self.deleteBtn = deleteBtn;
        [self addSubview:deleteBtn];
        
        [deleteBtn addTarget:self action:@selector(deleteClick) forControlEvents:UIControlEventTouchUpInside];
        
        //添加长按收拾
        [self addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressPageView:)]];
    }
    return self;
}

#pragma mark - 长按手势

//找出手指对应的表情按钮
- (NREmotionButton *)emotionButtonEithLoaction:(CGPoint)location{
   
    NSInteger count = self.emotions.count;
    for (int i = 0; i < count; i++) {
        NREmotionButton *btn = self.subviews[i + 1];
        if (CGRectContainsPoint(btn.frame, location)) {
            //找到手指所在的表情按钮，退出循环
            return btn;
        }
    }
    return nil;
    
}

- (void)longPressPageView:(UILongPressGestureRecognizer *)recognizer{
    //获得手指所在的位置的表情按钮
    CGPoint location = [recognizer locationInView:recognizer.view];
    
    NREmotionButton *btn = [self emotionButtonEithLoaction:location];
    
    switch (recognizer.state) {
            
            //收拾结束
        case UIGestureRecognizerStateEnded:
        case UIGestureRecognizerStateCancelled:
            
            //移除
            [self.popView removeFromSuperview];
            
            //如果手指还在表情按钮上 (不在表情键盘上)
            if (btn) {
                //发通知
                [self selectEmotion:btn.emotion];
            }
            
            break;
        case UIGestureRecognizerStateBegan:  //刚检测到收拾开始
        case UIGestureRecognizerStateChanged:{  //收拾改变(手指的位置改变)
            [self.popView showFrom:btn];
            break;
            
        }
        default: {
            break;
        }
    }
    
}


- (NREmotionPopView *)popView{
    if (!_popView) {
        _popView = [NREmotionPopView popView];
        _popView.backgroundColor = [UIColor clearColor];
    }
    return _popView;
}

- (void)setEmotions:(NSArray *)emotions{
    _emotions = emotions;
    NSInteger count = emotions.count;
    for (int i = 0; i < count; i++) {
        NREmotionButton *btn = [NREmotionButton new];
        btn.tag = i;
        [self addSubview:btn];

        //btn.backgroundColor = NRWRandomColor;
       
        //设置表情数据
        btn.emotion = emotions[i];
        
        //监听按钮
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
}

#pragma mark - 按钮的监听方法
//删除按钮的监听
- (void)deleteClick{
    [NRNotificationCenter postNotificationName:NREmotionDidDeleteNotification object:nil];
}


- (void)btnClick:(NREmotionButton *)btn{
    //显示popView
    [self.popView showFrom:btn];
    
    //等会popView消失
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.popView removeFromSuperview];
    });
     [self selectEmotion:btn.emotion];
    
}

//把表情存在沙盒里
/**
 *  选中某一个表情发通知
 *
 *  @param emotion 被点击的按钮
 */
- (void)selectEmotion:(NREmotion *)emotion{
    
    //将表情存入沙盒
    [NREmotionTool addRecentEmotion:emotion];
    
    
    //发通知
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    userInfo[NRemotionkey] = emotion;
    [NRNotificationCenter postNotificationName:NREmotionDidSelectedNotification object:nil userInfo:userInfo];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    CGFloat inset = 10;
    CGFloat btnW = (self.width - 2 * inset)/NREmotionMaxClos;
    CGFloat btnH = (self.height - inset)/NRemotionMaxLin;
    NSInteger count = self.emotions.count;
    for (int i = 0; i < count; i++) {
        UIButton *btn = self.subviews[i+1];
        btn.width = btnW;
        btn.height = btnH;
        btn.x = inset + (i % NREmotionMaxClos) * btnW;
        btn.y = inset + (i / NREmotionMaxClos) * btnH;
        
    }
    //删除按钮
    self.deleteBtn.width = btnW;
    self.deleteBtn.height = btnH;
    self.deleteBtn.y = self.height - btnH;
    self.deleteBtn.x = self.width - inset - btnW;

}
@end
