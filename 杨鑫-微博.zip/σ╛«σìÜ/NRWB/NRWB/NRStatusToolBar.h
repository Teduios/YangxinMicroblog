//
//  NRStatusToolBar.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/13.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NRWBStatus.h"
@class NRStatusToolBar;

typedef NS_ENUM(NSUInteger, NRStatusToolBarButtonType) {
    NRStatusToolBarButtonTypeZhuanFa,//转发
    NRStatusToolBarButtonTypePingLun,//评论
    NRStatusToolBarButtonTypeDianZan,//点赞
};

@interface NRStatusToolBar : UIView
+ (instancetype)toolBar;

@property(nonatomic, strong) NRWBStatus *status;

@end
