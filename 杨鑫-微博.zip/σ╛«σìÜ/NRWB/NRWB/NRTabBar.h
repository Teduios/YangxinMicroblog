//
//  NRTabBar.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/3.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NRTabBar;

@protocol NRTabBarDelegate <UITabBarDelegate>

- (void)tabBarDidClickPlushButton:(NRTabBar *)tabBar;

@end

@interface NRTabBar : UITabBar
@property(nonatomic, weak) id<NRTabBarDelegate> delegate;

@end
