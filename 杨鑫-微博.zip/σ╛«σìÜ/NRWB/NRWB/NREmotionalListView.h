//
//  NREmotionalListView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 表情键盘里面的内容(表情) */
@interface NREmotionalListView : UIView

/** 表情数组 (存放表情模型) */
@property(nonatomic, strong) NSArray *emotions;


@end 
