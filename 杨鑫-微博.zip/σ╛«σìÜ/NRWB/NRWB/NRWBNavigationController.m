//
//  NRWBNavigationController.m
//  微博R
//
//  Created by apple-jd42 on 15/10/31.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBNavigationController.h"

@interface NRWBNavigationController ()

@end

@implementation NRWBNavigationController

/**
 *  第一次使用类调用
 */
+ (void)initialize{
    //设置整个项目所有的item的肢体样式
    UIBarButtonItem *item = [UIBarButtonItem appearance];
    
    //设置普通状态
    //key:NS*****AttributrName
    NSMutableDictionary *textAtts = [NSMutableDictionary dictionary];
    textAtts[NSForegroundColorAttributeName] = [UIColor orangeColor];
    textAtts[NSFontAttributeName] = [UIFont systemFontOfSize:15];
    [item setTitleTextAttributes:textAtts forState:UIControlStateNormal];
    
    //设置不可点击状态
    NSMutableDictionary *disableTextAtts = [NSMutableDictionary dictionary];
    disableTextAtts[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:0.7];
    disableTextAtts[NSFontAttributeName] = textAtts[NSFontAttributeName];
    [item setTitleTextAttributes:disableTextAtts forState:UIControlStateDisabled];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}




/**
 *  重写这个方法的目的：能够拦截所有push进来的控制器
 *
 *  @param viewController 即将push进来的控制器
 */
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
   
    //配置除了根视图的导航栏
    if (self.viewControllers.count > 0) { //说明此时push进来的不是根视图控制器
        
        viewController.hidesBottomBarWhenPushed = YES;

        /**
         *  设置导航栏非主页左侧的按钮
         */
        viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self Action:@selector(back) image:@"navigationbar_back" highImage:@"navigationbar_back_highlighted"];
        
        /**
         *  设置导航栏非主页左侧的按钮
         */
        viewController.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTarget:self Action:@selector(more) image:@"navigationbar_more" highImage:@"navigationbar_more_highlighted"];

    }
     [super pushViewController:viewController animated:animated];
}

- (void)back{
    [self popViewControllerAnimated:YES];
}

- (void)more{
    [self popToRootViewControllerAnimated:YES];
}

@end
