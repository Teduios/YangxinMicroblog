//
//  NRTitleButton.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/7.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRTitleButton.h"
#define NRMargin 10


@implementation NRTitleButton

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.font = [UIFont systemFontOfSize:17];
        [self setImage:[UIImage imageNamed:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"navigationbar_arrow_up"] forState:UIControlStateSelected];
    }
    return self;
}
/**
 *  设置按钮内部的imageView的frame
 *
 *  @param contentRect 按钮的bounds
 *
 *  @return 返回按钮内部的imageView的frame
 */
//- (CGRect)imageRectForContentRect:(CGRect)contentRect{
//    CGFloat x = 80;
//    CGFloat y = 0;
//    CGFloat width = 13;
//    CGFloat height = contentRect.size.height;
//    return CGRectMake(x, y, width, height);
//}

/**
 *  设置按钮内部的titleLabel的frame
 *
 *  @param contentRect 按钮的bounds
 *
 *  @return 返回按钮内部的titleLabel的frame
 */
//- (CGRect)titleRectForContentRect:(CGRect)contentRect{
//    CGFloat x = 0;
//    CGFloat y = 0;
//    
//    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
//    attrs[NSFontAttributeName] = self.titleLabel.font;;
//    
//    //文字的宽度
//    CGFloat width = [self.currentTitle sizeWithAttributes:attrs].width;
//    CGFloat height = contentRect.size.height;
//    return CGRectMake(x, y, width, height);
//}

//目的是在系统设置万以后再修改它的尺寸
- (void)setFrame:(CGRect)frame{
    frame.size.width += NRMargin;
    [super setFrame:frame];
}

//只需要调整x的位置
- (void)layoutSubviews{
    
    //如果仅仅调整按钮内部的文字和图片的位置在次方单独设置位置就可以，不需要重写上面的方法
    [super layoutSubviews];
    
    //1.计算titleLabel的frame
    self.titleLabel.x = self.imageView.x;
    
    
    //2.计算imageView的frame
    self.imageView.x = CGRectGetMaxX(self.titleLabel.frame) + NRMargin;
    
}

- (void)setTitle:(NSString *)title forState:(UIControlState)state{
    [super setTitle:title forState:state];
    [self sizeToFit];
}

- (void)setImage:(UIImage *)image forState:(UIControlState)state{
    [super setImage:image forState:state];
    [self sizeToFit];
}
@end
