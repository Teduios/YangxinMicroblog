//
//  NRWBAccount.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/6.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBAccount.h"

@implementation NRWBAccount
+ (instancetype)accessWithDict:(NSDictionary *)dic{
    NRWBAccount *account  = [self new];
    account.access_token = dic[@"access_token"];
    account.uid = dic[@"uid"];
    account.expires_in = dic[@"expires_in"];
    
    //获得账号存储的时间（accessToken的产生时间）
    NSDate *creatdTime = [NSDate date];
    account.createdTime = creatdTime;

    
    return account;
}

/**
 *  当一个对象要归档进沙盒中时，就会调用这个方法
 *  目的：这个方法中说明这个对象的哪些属性要存进沙盒里
 *
 *  @param aCoder 编码器
 */
- (void)encodeWithCoder:(NSCoder *)aCoder{
    
    [aCoder encodeObject:self.access_token forKey:@"access_token"];
    [aCoder encodeObject:self.expires_in forKey:@"expires_in"];
    [aCoder encodeObject:self.uid forKey:@"uid"];
    [aCoder encodeObject:self.createdTime forKey:@"createdTime"];
    [aCoder encodeObject:self.name forKey:@"name"];

    
}

/**
 *  解档的时候调用该方法
 *  目的：说明沙盒的属性怎么解档
 */
- (id)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        self.access_token = [aDecoder decodeObjectForKey:@"access_token"];
        self.expires_in = [aDecoder decodeObjectForKey:@"expires_in"];
        self.uid = [aDecoder decodeObjectForKey:@"uid"];
        self.createdTime = [aDecoder decodeObjectForKey:@"createdTime"];
        self.name = [aDecoder decodeObjectForKey:@"name"];
    }
    return self;
}

@end
