//
//  NREmotionTabBar.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionTabBar.h"
#import "NREmotionTabBarButton.h"

@interface NREmotionTabBar()
@property(nonatomic, strong) NREmotionTabBarButton *selectedBtn;
@end

@implementation NREmotionTabBar

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupButton:@"最近" btnType:NREmotionTabBarBtnTypeRecent];
       // [self btnClick: [self setupButton:@"默认" btnType:NREmotionTabBarBtnTypeDefault]];
        [self setupButton:@"默认" btnType:NREmotionTabBarBtnTypeDefault];
        [self setupButton:@"Emoji" btnType:NREmotionTabBarBtnTypeEmoji];
        [self setupButton:@"浪小花" btnType:NREmotionTabBarBtnTypeLXH];
    }
    return self;
}

/** 创建一个按钮 */
- (NREmotionTabBarButton *)setupButton:(NSString *)title btnType:(NREmotionTabBarBtnType)btnType{
    NREmotionTabBarButton *btn = [NREmotionTabBarButton new];
    [self addSubview:btn];
    btn.tag = btnType;
    
    [btn setTitle:title forState:UIControlStateNormal];
    
    //监听按钮点击事件
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchDown];
    
    //设置背景图片
    NSString *image = nil;
    NSString *selectImage = nil;
    if (self.subviews.count == 1) {
        image = @"compose_emotion_table_left_normal";
        selectImage = @"compose_emotion_table_left_selected";
    }else if (self.subviews.count == 4){
        image = @"compose_emotion_table_right_normal";
        selectImage = @"compose_emotion_table_right_selected";
    }else{
        image = @"compose_emotion_table_mid_normal";
        selectImage = @"compose_emotion_table_mid_selected";
    }
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:selectImage] forState:UIControlStateDisabled];
    return btn;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    NSInteger count = self.subviews.count;
    CGFloat btnW = self.width/count;
    CGFloat btnH = self.height;
    for (int i = 0; i < count; i++) {
        NREmotionTabBarButton *btn = self.subviews[i];
        btn.y = 0;
        btn.width = btnW;
        btn.x = i * btnW;
        btn.height = btnH;
    }

}

- (void)setDelegate:(id<NREmotionTabBarDelegate>)delegate{
    _delegate = delegate;
    
    //默认为选中默认按钮
    [self btnClick:(NREmotionTabBarButton *)[self viewWithTag:NREmotionTabBarBtnTypeDefault]];
  

}

#pragma mark - 点击按钮事件
- (void)btnClick:(NREmotionTabBarButton *)btn{
    self.selectedBtn.enabled = YES;
    btn.enabled = NO;
    self.selectedBtn = btn;
    
    //通知代理
    if ([self.delegate respondsToSelector:@selector(emotionTabBar:didSelectButton:)]) {
        [self.delegate emotionTabBar:self didSelectButton:btn.tag];
    }
}

@end
