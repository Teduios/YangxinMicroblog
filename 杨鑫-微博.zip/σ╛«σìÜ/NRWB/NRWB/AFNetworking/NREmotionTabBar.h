//
//  NREmotionTabBar.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger, NREmotionTabBarBtnType) {
    NREmotionTabBarBtnTypeRecent, //最近
    NREmotionTabBarBtnTypeDefault, //默认
    NREmotionTabBarBtnTypeEmoji, //Emoji
    NREmotionTabBarBtnTypeLXH//浪小花
};
@class NREmotionTabBar;

@protocol NREmotionTabBarDelegate <NSObject>

- (void)emotionTabBar:(NREmotionTabBar *)tabBar didSelectButton:(NREmotionTabBarBtnType)btnType;

@end

/** 表情键盘底部的选项卡 */
@interface NREmotionTabBar : UIView
@property(nonatomic, weak) id<NREmotionTabBarDelegate> delegate;

@end
