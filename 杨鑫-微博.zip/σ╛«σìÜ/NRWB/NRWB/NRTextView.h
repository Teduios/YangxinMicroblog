//
//  NRTextView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/17.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

//带有占位文字的textView

@interface NRTextView : UITextView

/** 占位文字 */
@property(nonatomic, copy) NSString *placeholder;

/** 占位文字的颜色 */
@property(nonatomic, strong) UIColor *placeholderColor;

@end
