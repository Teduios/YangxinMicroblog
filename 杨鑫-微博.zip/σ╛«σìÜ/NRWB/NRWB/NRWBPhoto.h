//
//  NRWBPhoto.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/12.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NRWBPhoto : NSObject

/** 缩略图 */
@property(nonatomic, strong) NSString *thumbnail_pic;
@end
