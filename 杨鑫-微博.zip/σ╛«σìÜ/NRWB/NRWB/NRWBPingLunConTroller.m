//
//  NRWBPingLunConTroller.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/21.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBPingLunConTroller.h"
#import "NRWBAccountTool.h"
#import "NREmotionTextView.h"

@implementation NRWBPingLunConTroller

- (void)cancle{
    [super cancle];
    [self.navigationController popViewControllerAnimated:YES];
}


/** 设置导航栏 */
- (void)setupNav{

    [super setupNav];
    
    NSString *name = [NRWBAccountTool account].name;
    NSString *prefix = @"发表评论";
    if (name) {
        UILabel *titleView = [UILabel new];
        titleView.width = 200;
        titleView.height = 45;
        titleView.numberOfLines = 0;
        //titleView.backgroundColor = [UIColor redColor];
        titleView.textAlignment = NSTextAlignmentCenter;
        NSString *str = [NSString stringWithFormat:@"%@\n%@", prefix, name];
        //有样式的文字 (创建一个带有属性的字符串【比如文字的颜色，字体】)
        NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:str];
        
        //添加属性
        [attrStr addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:16] range:[str rangeOfString:prefix]];
        [attrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:[str rangeOfString:name]];
        
        
        titleView.attributedText = attrStr;
        
        self.navigationItem.titleView = titleView;
        
    }else{
        self.title = prefix;
    }
    
}

- (void)setupTextView{
    [super setupTextView];
       self.textView.placeholder = @"写评论....";
    //    self.textView.placeholderColor = [UIColor redColor];
    
}

#pragma mark - 评论微博
- (void)send{
    //[super send];
    //转发微博的URL：https://api.weibo.com/2/comments/create.json
    //参数
   // access_token	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
  //  comment	true	string	评论内容，必须做URLencode，内容不超过140个汉字。
    //id	true	int64	需要评论的微博ID。
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [NRWBAccountTool account].access_token;
    params[@"id"] = self.statue.idstr;
    params[@"comment"] = self.textView.fullText;
    
    //只能发有文字的微博
    // 3.发送请求
    [mgr POST:@"https://api.weibo.com/2/comments/create.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        [MBProgressHUD showSuccess:@"评论成功"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"评论失败"];
    }];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}




- (void)viewDidLoad{
    [super viewDidLoad];
}

@end
