//
//  NRIconView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/16.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRIconView.h"
#import "UIImageView+WebCache.h"

@interface NRIconView()
@property(nonatomic, strong) UIImageView *verifiedView;
@end

@implementation NRIconView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.layer.cornerRadius = 35 / 2;
    }
    return self;
}

- (UIImageView *)verifiedView{
    if (!_verifiedView) {
        _verifiedView = [UIImageView new];
        [self addSubview:_verifiedView];
    }
    return _verifiedView;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (void)setUser:(NRWBUser *)user{
    _user = user;
    
    //1.下载图片
    [self sd_setImageWithURL:[NSURL URLWithString:user.profile_image_url] placeholderImage:[UIImage imageNamed:@"avatar_default_small"]];
    
    //2.设置加v图片
    self.verifiedView.hidden = NO;
    switch (user.verified_type) {
//        case NRWBUserVerifiedTypeNone: //没有认证
//            self.verifiedView.hidden = YES;
//            break;
        case NRWBUserVerifiedTypePersonal://个人认证
            self.verifiedView.image = [UIImage imageNamed:@"avatar_vip"];

            break;
        case NRWBUserVerifiedTypeEnterpric://企业
        case NRWBUserVerifiedTypeMedia: //媒体
        case NRWBUserVerifiedTypeWebsite://网站官方
            self.verifiedView.image = [UIImage imageNamed:@"avatar_enterprise_vip"];

            break;
     
        case NRWBUserVerifiedTypeDare: //微博达人
            self.verifiedView.image = [UIImage imageNamed:@"avatar_grassroot"];

            break;
 
        default:
             self.verifiedView.hidden = YES; //没有任何认证
            break;
       
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.verifiedView.size = self.verifiedView.image.size;
    self.verifiedView.x = self.width - self.verifiedView.width * 0.7;
    self.verifiedView.y = self.height - self.verifiedView.height * 0.7;
}
@end
