//
//  NRWBAccountTool.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/6.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBAccountTool.h"

#define NRWBAccountPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject  stringByAppendingPathComponent:@"account.archive"]

@implementation NRWBAccountTool
+ (void)saveAccount:(NRWBAccount *)account{
    
    //普通对象写入沙盒必须是使用NSKeyedArchiver，而不是writeToFile
    [NSKeyedArchiver archiveRootObject:account toFile:NRWBAccountPath];
}


+ (NRWBAccount *)account{
    //加载模型
    NRWBAccount *account =  [NSKeyedUnarchiver unarchiveObjectWithFile:NRWBAccountPath];
    
    //验证账号时候过期
    long long expiresIn = [account.expires_in longLongValue];
    
    //账号产生时间
    NSDate *expiresTime =  [account.createdTime dateByAddingTimeInterval:expiresIn];
    
    //获得当前时间
    NSDate *now = [NSDate date];
    
    //如果now大于expiresTime就等于过期
    /*
     *  NSOrderedAscending = -1L(升序(右>左)) , NSOrderedSame(一样) , NSOrderedDescending(降序)
     */
    NSComparisonResult result =  [expiresTime compare:now];
    if (result != NSOrderedDescending) { //过期
        return nil;
    }
    
    
    return account;

}
@end
