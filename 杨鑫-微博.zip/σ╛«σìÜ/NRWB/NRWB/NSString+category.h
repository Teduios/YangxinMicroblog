//
//  NSString+category.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/14.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (category)
- (CGSize)sizeWithfont:(UIFont *)font maxW:(CGFloat)maxW;
- (CGSize)sizeWithfont:(UIFont *)font;

@end
