//
//  NRphView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/16.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NRWBPhoto.h"

@interface NRphView : UIImageView
@property(nonatomic, strong) NRWBPhoto *photo;
@end
