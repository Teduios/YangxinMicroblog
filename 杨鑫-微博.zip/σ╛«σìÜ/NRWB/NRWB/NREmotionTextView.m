//
//  NREmotionTextView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionTextView.h"
#import "UITextView+category.h"

@implementation NREmotionTextView

- (void)insertEmotion:(NREmotion *)emotion{
    
     //insetText:将文字插入到光标所在的位置
     if (emotion.code) {
     [self insertText:emotion.code.emoji];
     }else if(emotion.png){
        
         //加载图片
         NREmotionAttachment *attch = [NREmotionAttachment new];
         
         //自定义attch
         attch.emotion = emotion;
         
//         attch.image = [UIImage imageNamed:emotion.png];
         //设置图片的尺寸
         CGFloat attchWH = self.font.lineHeight;
         attch.bounds = CGRectMake(0, -4, attchWH, attchWH);
         
         //根据附加条件创建一个带有熟悉文字
         NSAttributedString *imageStr = [NSAttributedString attributedStringWithAttachment:attch];
         
        [self insertAttributeText:imageStr setTingBlock:^(NSMutableAttributedString *attributeText) {
            [attributeText addAttribute:NSFontAttributeName value:self.font range:NSMakeRange(0, attributeText.length)];
        }];
         
         
     }
}

- (NSString *)fullText{
    NSMutableString *fullText = [NSMutableString new];
    
    //遍历attributedText里面所有的文本
    [self.attributedText enumerateAttributesInRange:NSMakeRange(0, self.attributedText.length) options:0 usingBlock:^(NSDictionary<NSString *,id> * _Nonnull attrs, NSRange range, BOOL * _Nonnull stop) {
        
        NREmotionAttachment *attch = attrs[@"NSAttachment"];
        
        if (attch) {//文本里面带有表情
            [fullText appendString:attch.emotion.chs];
            
        }else{//emjio或普通文本
            //获得rang范围内的文字
            NSAttributedString *str = [self.attributedText attributedSubstringFromRange:range];
            [fullText appendString:str.string];
        }
    }];
    
    return fullText;
}

@end
