//
//  NRZhuanFaController.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/21.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NRWBStatus.h"
#import "NREmotionTextView.h"

@interface NRZhuanFaController : UIViewController
@property(nonatomic, strong) NRWBStatus *statue;

/** 输入控件 */
@property(nonatomic, strong) NREmotionTextView *textView;

//取消操作
- (void)cancle;

/** 设置导航栏 */
- (void)setupNav;

/** 添加输入控件 */
- (void)setupTextView;

/** 发送按钮 */
- (void)send;
@end
