//
//  NRphView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/16.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRphView.h"
#import "UIImageView+WebCache.h"
@interface NRphView()
@property(nonatomic, strong) UIImageView *gifView;
@end
@implementation NRphView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (UIImageView *)gifView{
    if (!_gifView) {
        UIImage *image = [UIImage imageNamed:@"timeline_image_gif"];
        self.gifView= [[UIImageView alloc] initWithImage:image];
        [self addSubview:self.gifView];
    }
    return _gifView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        //内容模式
        /**
         UIViewContentModeScaleToFill,
         UIViewContentModeScaleAspectFit,      // contents scaled to fit with fixed aspect. remainder is transparent
         UIViewContentModeScaleAspectFill,     // contents scaled to fill with fixed aspect. some portion of content may be clipped.
         UIViewContentModeRedraw,              // redraw on bounds change (calls -setNeedsDisplay)
         UIViewContentModeCenter,              // contents remain same size. positioned adjusted.
         UIViewContentModeTop,
         UIViewContentModeBottom,
         UIViewContentModeLeft,
         UIViewContentModeRight,
         UIViewContentModeTopLeft,
         UIViewContentModeTopRight,
         UIViewContentModeBottomLeft,
         UIViewContentModeBottomRight,
         */
        /**
         0.fill是填充范围的大小
         1.凡是带有Scale单词的，图片都会拉伸
         2.凡是带有Aspect单词的，都会保持宽高比拉伸
         */
        self.contentMode = UIViewContentModeScaleAspectFill;
        
        //超出范围内的内容剪切掉
        self.clipsToBounds = YES;
    }
    return self;
}

- (void)setPhoto:(NRWBPhoto *)photo{
    _photo = photo;
    //设置图片
     [self sd_setImageWithURL:[NSURL URLWithString:photo.thumbnail_pic] placeholderImage:[UIImage imageNamed:@"timeline_image_placeholder"]];
    
    //显示gif
    //是否与gif结尾
//    if ([photo.thumbnail_pic hasSuffix:@"gif"]) {
//        self.gifView.hidden = NO;//显示不隐藏
//    }else{
//        self.gifView.hidden = YES;
//    }
    //lowercaseString把大写改成小写再做判断因为有可能是GIF或gif结尾的
    self.gifView.hidden =![photo.thumbnail_pic.lowercaseString hasSuffix:@"gif"];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.gifView.x = self.width - self.gifView.width;
    self.gifView.y = self.height - self.gifView.height;
}

@end
