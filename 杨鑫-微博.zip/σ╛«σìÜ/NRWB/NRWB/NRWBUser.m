//
//  NRWBUser.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/7.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBUser.h"

@implementation NRWBUser

- (void)setMbtype:(NSInteger)mbtype{
    _mbtype = mbtype;
   // self.vip = mbtype > 2;
}

- (BOOL)isVip{
    return self.mbtype > 2;
}
@end
