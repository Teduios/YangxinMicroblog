//
//  NRWBNewfeatureController.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/3.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBNewfeatureController.h"
#import "NRWBTabBarController.h"
#define NRNEWFEATURECOUNT 4

@interface NRWBNewfeatureController () <UIScrollViewDelegate>
@property(nonatomic, strong) UIPageControl *pageControl;
@end

@implementation NRWBNewfeatureController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //1.创建Scrollllview：显示所有新特性图片
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    scrollView.delegate = self;

    
    [self.view addSubview:scrollView];
    
    //2.添加图片到scrollView
    CGFloat scrollW = scrollView.width;
    for (int i = 0; i < NRNEWFEATURECOUNT; i++) {
        UIImageView *imageView = [[UIImageView alloc] init];
        [scrollView addSubview:imageView];
        imageView.size = scrollView.size;
        imageView.x = i * scrollW;
        imageView.y = 0;
        NSString *name = [NSString stringWithFormat:@"new_feature_%d", i + 1];
        imageView.image = [UIImage imageNamed:name];
        
        //判断如果是最后一个imageView，就往里面添加其他的内容
        if (i == NRNEWFEATURECOUNT - 1) {
            [self setupLastImageView:imageView];
        }
    }
    
    //3.scrollView的其他属性
    scrollView.contentSize = CGSizeMake(NRNEWFEATURECOUNT * scrollW, 0);
    scrollView.bounces = NO;
    scrollView.pagingEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = NO;
    
    //4.添加pageControl
    UIPageControl *pageControl = [UIPageControl new];
    [self.view addSubview:pageControl];
    pageControl.numberOfPages = NRNEWFEATURECOUNT;
    pageControl.centerX = scrollW * 0.5;
    pageControl.centerY = scrollView.height - 50;
    pageControl.currentPageIndicatorTintColor = NRWColor(253, 98, 42);
    pageControl.pageIndicatorTintColor = NRWColor(189, 189, 189);
    self.pageControl = pageControl;
}
- (void)setupLastImageView:(UIImageView *)imageView{
    
    imageView.userInteractionEnabled = YES;
    //1.分享按钮(checkbox)
    UIButton *shareBtn = [UIButton new];
    [shareBtn setImage:[UIImage imageNamed:@"new_feature_share_false"] forState:UIControlStateNormal];
    [shareBtn setImage:[UIImage imageNamed:@"new_feature_share_true"] forState:UIControlStateSelected];
    [shareBtn setTitle:@"分享给大家" forState:UIControlStateNormal];
    [shareBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    shareBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [shareBtn addTarget:self action:@selector(sharClick:) forControlEvents:UIControlEventTouchUpInside];
    shareBtn.width = 200;
    shareBtn.height = 30;
    shareBtn.centerX = imageView.width * 0.5;
    shareBtn.centerY = imageView.height * 0.75;
    [imageView addSubview:shareBtn];
    shareBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
    shareBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5);
    
    //2.进入微博
    UIButton *startBtn = [UIButton new];
    [startBtn setBackgroundImage:[UIImage imageNamed:@"new_feature_finish_button"] forState:UIControlStateNormal];
    [startBtn setBackgroundImage:[UIImage imageNamed:@"new_feature_finish_button_highlighted"] forState:UIControlStateHighlighted];
    startBtn.size = startBtn.currentBackgroundImage.size;
    startBtn.centerX = shareBtn.centerX;
    startBtn.centerY = imageView.height * 0.81;
    [startBtn setTitle:@"进入微博" forState:UIControlStateNormal];
    [imageView addSubview:startBtn];
    [startBtn addTarget:self action:@selector(startClick) forControlEvents:UIControlEventTouchUpInside];
    
}

//分享按钮
- (void)sharClick:(UIButton *)shareBtn{
    shareBtn.selected = !shareBtn.isSelected;
}

//进入微博按钮
- (void)startClick{
    //切换控制器的方式
    /*
     1.push
     2.modal(present.......)
     3.改变window的根视图(rootViewController)
     */
   UIWindow *window =  [UIApplication sharedApplication].keyWindow;
    window.rootViewController = [NRWBTabBarController new];
    
}

#pragma mark - UIscrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat page = scrollView.contentOffset.x / scrollView.width;
    self.pageControl.currentPage = round(page);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
