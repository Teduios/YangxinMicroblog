//
//  NRStatusCell.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/11.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NRStatusToolBar.h"

@class NRWBStatusFrame;

@interface NRStatusCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@property(nonatomic, strong) NRWBStatusFrame *statusFrame;

/** 工具条 */
@property(nonatomic, strong) NRStatusToolBar *toolBar;
@end
