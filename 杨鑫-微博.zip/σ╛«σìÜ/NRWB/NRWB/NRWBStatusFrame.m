//
//  NRWBStatusFrame.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/11.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBStatusFrame.h"
#import "NRWBUser.h"
#import "NRWBStatusPhotoView.h"

@implementation NRWBStatusFrame

- (void)setStatus:(NRWBStatus *)status{
    _status = status;
    NRWBUser *user = status.user;
   
    //cell的宽度
    CGFloat cellW = [UIScreen mainScreen].bounds.size.width;
    
    //头像
    CGFloat iconWH = 35;
    CGFloat iconX = kStatusCellBordeeW;
    CGFloat iconY = kStatusCellBordeeW;
    self.iconViewFrame = CGRectMake(iconX, iconY, iconWH, iconWH);
    
     //昵称
    CGFloat nameX = CGRectGetMaxX(self.iconViewFrame) + kStatusCellBordeeW;
    CGFloat nameY = iconY;
    CGSize nameSize = [user.name sizeWithfont:kStatusCellNameFont];
//    self.nameLabelFrame = CGRectMake(nameX, nameY, nameSize.width, nameSize.height);
    self.nameLabelFrame = (CGRect){{nameX, nameY}, nameSize};
    
    //会员图标
    if(user.isVip){
        CGFloat vipX = CGRectGetMaxX(self.nameLabelFrame) + kStatusCellBordeeW;
        CGFloat vipY = nameY;
        CGFloat vipH = nameSize.height;
        CGFloat vipW = 14;
        self.vipViewFrame = CGRectMake(vipX, vipY, vipW, vipH);
    }
    
    //发微博的时间
    CGFloat timeX = nameX;
    CGFloat timeY = CGRectGetMaxY(self.nameLabelFrame) + kStatusCellBordeeW;
    CGSize timeSize = [status.created_at sizeWithfont:kStatusCellTimeFont];
    self.timeLabelFrame = (CGRect){{timeX, timeY}, timeSize};
    
    // 来源
    CGFloat sourceX = CGRectGetMaxX(self.timeLabelFrame) + kStatusCellBordeeW;
    CGFloat sourceY = timeY;
    CGSize sourceSize = [status.source sizeWithfont:kStatusCellSourceFont];
    self.sourceLabelFrame = (CGRect){{sourceX, sourceY}, sourceSize};
    
     //正文
    CGFloat contentX = iconX;
    CGFloat contentY = MAX(CGRectGetMaxY(self.iconViewFrame), CGRectGetMaxY(self.timeLabelFrame)) + kStatusCellBordeeW;
    CGFloat maxW = cellW - 2 * contentX;
    CGSize contentSize = [status.text sizeWithfont:kStatusCellTextFont maxW:maxW];
    self.contentLabelFrame = (CGRect){{contentX, contentY}, contentSize};

    //配图
    CGFloat originalH = 0;
    if (status.pic_urls.count) {//有配图
        CGFloat photoX = contentX;
        CGFloat photoY = CGRectGetMaxY(self.contentLabelFrame) + kStatusCellBordeeW;
        CGSize photoSize = [NRWBStatusPhotoView SizeWithCount:status.pic_urls.count];
        self.photoViewFrame = (CGRect){{photoX, photoY}, photoSize};
        
        originalH = CGRectGetMaxY(self.photoViewFrame) + kStatusCellBordeeW;
    }else{//没有配图
        originalH = CGRectGetMaxY(self.contentLabelFrame) + kStatusCellBordeeW;
    }
   
    
    
   //原创微博整体
    CGFloat originalX = 0;
    CGFloat originalY = 0;
    CGFloat originalW = cellW;
    self.originalViewFrame = CGRectMake(originalX, originalY, originalW, originalH);
    
    
    CGFloat toolBarY = 0;
    //被转发微博的
    if (status.retweeted_status) {
        //被转发微博的正文
        
        NRWBStatus *retweeted_status = status.retweeted_status;
        NRWBUser *retweeted_status_Uesr = retweeted_status.user;

        CGFloat retweetContentX = kStatusCellBordeeW;
        CGFloat retweetContentY = kStatusCellBordeeW;
        
        NSString *retweetContent = [NSString stringWithFormat:@"@%@:%@", retweeted_status_Uesr.name, retweeted_status.text];
        
        CGSize retweetContentSize =  [retweetContent sizeWithfont:kStatusCellRetweetTextFont maxW:maxW];
        self.retweetContentLabelF = (CGRect){{retweetContentX, retweetContentY}, retweetContentSize};
        
         //被转发微博的配图
        CGFloat retweetH = 0;
        if (retweeted_status.pic_urls.count) { //有图
            CGFloat retweetPhotoX = retweetContentX;
            CGFloat retweetPhotoY = CGRectGetMaxY(self.retweetContentLabelF) + kStatusCellBordeeW;
            
            CGSize retweetPhotoSize = [NRWBStatusPhotoView SizeWithCount:retweeted_status.pic_urls.count];
            self.retweetphotoViewF = (CGRect){{retweetPhotoX, retweetPhotoY}, retweetPhotoSize};
            
            retweetH = CGRectGetMaxY(self.retweetphotoViewF) + kStatusCellBordeeW;
        }else{
            retweetH = CGRectGetMaxY(self.retweetContentLabelF) + kStatusCellBordeeW;

        }
        
        //被转发微博的整体
        CGFloat retweetViewX = 0;
        CGFloat retweetViewY = CGRectGetMaxY(self.originalViewFrame);
        CGFloat retweetW = cellW;
        self.retweetViewF = CGRectMake(retweetViewX, retweetViewY, retweetW, retweetH);
        
        toolBarY = CGRectGetMaxY(self.retweetViewF);

    }else{
         toolBarY = CGRectGetMaxY(self.originalViewFrame);
          }
    
    /**  工具条 */
    CGFloat toolBarX = 0;
    CGFloat toolBarW = cellW;
    CGFloat toolBarH = 40;
    self.toolBarFrame = CGRectMake(toolBarX, toolBarY, toolBarW, toolBarH);
    
    /** cell的高度 */
    self.cellHeight = CGRectGetMaxY(self.toolBarFrame) + kStatusCellMarginW;

   
}

@end
