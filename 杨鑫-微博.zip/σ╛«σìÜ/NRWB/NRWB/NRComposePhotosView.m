//
//  NRComposePhotosView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/18.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRComposePhotosView.h"

@interface NRComposePhotosView ()
@end


@implementation NRComposePhotosView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        _photos = [NSMutableArray array];
    }
    return self;
}

- (void)addPhoto:(UIImage *)photo{
    UIImageView *photoView =  [UIImageView new];
    [self addSubview:photoView];
    photoView.image = photo;
    [self.photos addObject:photo];
}


- (void)layoutSubviews{
    [super layoutSubviews];
    //设置图片的尺寸
    NSInteger photoCount = self.subviews.count;
    CGFloat imageWH = 80;
    CGFloat imageMargin = 10;
    for (NSInteger i = 0; i < photoCount; i++) {
        UIImageView *photoImageView = self.subviews[i];
        
        
        //图片在几列
        NSInteger col = i % 4;
        photoImageView.x = col * (imageWH + imageMargin);
        
        ////图片在几行
        NSInteger row = i / 4;
        photoImageView.y = row * (imageWH + imageMargin);;
        photoImageView.width = imageWH;
        photoImageView.height = imageWH;
        
        
        
        
    }

}

//- (NSArray *)photos{
//    NSMutableArray *photots = [NSMutableArray array];
//    for (UIImageView *imageView in self.subviews) {
//        [photots addObject:imageView.image];
//    }
//    return photots;
//}

@end
