//
//  NREmotionPopView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NREmotion.h"
#import "NREmotionButton.h"

@interface NREmotionPopView : UIView

+ (instancetype)popView;
- (void)showFrom:(NREmotionButton *)btn;
@end
