//
//  NREmotionTabBarButton.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionTabBarButton.h"

@implementation NREmotionTabBarButton

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        //设置文字颜色
        [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self setTitleColor:[UIColor darkGrayColor] forState:UIControlStateDisabled];
        self.titleLabel.font = [UIFont systemFontOfSize:13];

    }
    return self;
}

- (void)setHighlighted:(BOOL)highlighted{
    //按钮高亮所做的一切都不见了
}
@end
