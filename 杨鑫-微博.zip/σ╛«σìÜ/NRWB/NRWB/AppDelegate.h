//
//  AppDelegate.h
//  NRWB
//
//  Created by apple-jd42 on 15/10/31.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

