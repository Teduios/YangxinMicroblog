//
//  NREmotionAttachment.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/21.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionAttachment.h"

@implementation NREmotionAttachment

- (void)setEmotion:(NREmotion *)emotion{
    _emotion =emotion;
    self.image = [UIImage imageNamed:emotion.png];
}
@end
