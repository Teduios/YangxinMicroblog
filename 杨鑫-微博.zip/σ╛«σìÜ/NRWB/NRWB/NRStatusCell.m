//
//  NRStatusCell.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/11.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRStatusCell.h"
#import "UIImageView+WebCache.h"
#import "NRWBStatusFrame.h"
#import "NRWBUser.h"
#import "NRWBPhoto.h"
#import "NRWBStatusPhotoView.h"
#import "NRIconView.h"


@interface NRStatusCell()
/** 原创微博 */

/** 原创微博整体 */
@property(nonatomic, strong) UIView *originalView;

/** 头像 */
@property(nonatomic, strong) NRIconView *iconView;

/** 会员图标 */
@property(nonatomic, strong) UIImageView *vipView;

/** 配图 */
@property(nonatomic, strong) NRWBStatusPhotoView *photoView;

/** 昵称 */
@property(nonatomic, strong) UILabel *nameLabel;

/** 发微博的时间 */
@property(nonatomic, strong) UILabel *timeLabel;

/** 来源 */
@property(nonatomic, strong) UILabel *sourceLabel;

/** 正文 */
@property(nonatomic, strong) UILabel *contentLabel;

/* 转发微博 */
/** 转发微博整体 */
@property (nonatomic, weak) UIView *retweetView;
/** 转发微博正文 + 昵称 */
@property (nonatomic, weak) UILabel *retweetContentLabel;
/** 转发配图 */
@property (nonatomic, weak) NRWBStatusPhotoView *retweetPhotoView;


///** 工具条 */
//@property(nonatomic, strong) NRStatusToolBar *toolBar;

@end

@implementation NRStatusCell

+  (instancetype)cellWithTableView:(UITableView *)tableView{
    static NSString *ID = @"status";
    NRStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[NRStatusCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.backgroundColor = [UIColor clearColor];
        
    
       // self.selectionStyle = UITableViewCellSelectionStyleNone;
        //初始化原创微博
        [self setupOriginal];
        
        //初始化转发微博
        [self setupRetweet];
        
        //初始化工具条
        [self setupToolBar];
    }
    return self;
}

/** 初始化工具条 */
- (void)setupToolBar{
    self.toolBar = [NRStatusToolBar toolBar];
    [self.contentView addSubview:self.toolBar];
}

/** 初始化转发微博 */
- (void)setupRetweet{
    /** 转发微博整体 */
    UIView *retweetView = [[UIView alloc] init];
    retweetView.backgroundColor = NRWColor(247, 247, 247);
    [self.contentView addSubview:retweetView];
    self.retweetView = retweetView;

    
    /** 转发微博正文 + 昵称 */
    UILabel *retweetContentLabel = [[UILabel alloc] init];
    retweetContentLabel.numberOfLines = 0;
    retweetContentLabel.font = kStatusCellRetweetTextFont;
    [retweetView addSubview:retweetContentLabel];
    self.retweetContentLabel = retweetContentLabel;
    
    /** 转发微博配图 */
    NRWBStatusPhotoView *retweetPhotoView = [[NRWBStatusPhotoView alloc] init];
    [retweetView addSubview:retweetPhotoView];
    self.retweetPhotoView = retweetPhotoView;
}



/** 初始化原创微博 */
- (void)setupOriginal{
    //原创微博整体
    _originalView = [UIView new];
    self.originalView.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:_originalView];
    
    //头像
    _iconView = [NRIconView new];
    [self.originalView addSubview:_iconView];
    
    //会员图标
    _vipView = [UIImageView new];
    _vipView.contentMode = UIViewContentModeCenter;
    [_originalView addSubview:_vipView];
    
    //配图
    _photoView = [NRWBStatusPhotoView new];
    [_originalView addSubview:_photoView];
    
    //昵称
    _nameLabel = [UILabel new];
    _nameLabel.font = kStatusCellNameFont;
    [_originalView addSubview:_nameLabel];
    
    //来源
    _sourceLabel = [UILabel new];
    _sourceLabel.font = kStatusCellSourceFont;
    [_originalView addSubview:_sourceLabel];
    
    //发微博的时间
    _timeLabel = [UILabel new];
    _timeLabel.font = kStatusCellTimeFont;
    _timeLabel.textColor = [UIColor orangeColor];
    [_originalView addSubview:_timeLabel];
    
    //正文
    _contentLabel = [UILabel new];
    _contentLabel.font = kStatusCellTextFont;
    _contentLabel.numberOfLines = 0;
    [_originalView addSubview:_contentLabel];

}

- (void)setStatusFrame:(NRWBStatusFrame *)statusFrame{
    
    _statusFrame = statusFrame;
    
    NRWBStatus *status = statusFrame.status;
    NRWBUser *user = status.user;
    
    //原创微博整体
    self.originalView.frame = statusFrame.originalViewFrame;
    
    //头像
    self.iconView.frame = statusFrame.iconViewFrame;
    self.iconView.user = user;
    
    //会员图标
    if (user.isVip) {
        self.vipView.hidden = NO;
        self.vipView.frame = statusFrame.vipViewFrame;
        NSString *vipName = [NSString stringWithFormat:@"common_icon_membership_level%ld", user.mbrank];
        self.vipView.image = [UIImage imageNamed:vipName];
        self.nameLabel.textColor = [UIColor orangeColor];
        
    }else{
        self.nameLabel.textColor = [UIColor blackColor];
        self.vipView.hidden = YES;
    }
    
    //配图
    if (status.pic_urls.count) {
        self.photoView.frame = statusFrame.photoViewFrame;
        self.photoView.photos = status.pic_urls;
        self.photoView.hidden = NO;
    }else{
        self.photoView.hidden = YES;
    }
    
    
    //昵称
    self.nameLabel.frame = statusFrame.nameLabelFrame;
    self.nameLabel.text = user.name;
    
    //来源
    self.sourceLabel.text = status.source;
    self.sourceLabel.frame = statusFrame.sourceLabelFrame;
    
    
    
    //发微博的时间
    NSString *time = status.created_at;
    CGFloat timeX = statusFrame.nameLabelFrame.origin.x;
    CGFloat timeY = CGRectGetMaxY(statusFrame.nameLabelFrame) + kStatusCellBordeeW;
    CGSize timeSize = [time sizeWithfont:kStatusCellTimeFont];
    self.timeLabel.frame = (CGRect){{timeX, timeY}, timeSize};
    self.timeLabel.text = time;
    
    // 来源
    CGFloat sourceX = CGRectGetMaxX(self.timeLabel.frame) + kStatusCellBordeeW;
    CGFloat sourceY = timeY;
    CGSize sourceSize = [status.source sizeWithfont:kStatusCellSourceFont];
    self.sourceLabel.frame = (CGRect){{sourceX, sourceY}, sourceSize};
    self.sourceLabel.text= status.source;
    
     
    //正文
    self.contentLabel.text = status.text;
    self.contentLabel.frame = statusFrame.contentLabelFrame;
    
    /** 被转发的微博 */
    if (status.retweeted_status) {
        NRWBStatus *retweeted_status = status.retweeted_status;
        NRWBUser *retweeted_status_user = retweeted_status.user;
        
        self.retweetView.hidden = NO;
        /** 被转发的微博整体 */
        self.retweetView.frame = statusFrame.retweetViewF;
        
        /** 被转发的微博正文 */
        NSString *retweetContent = [NSString stringWithFormat:@"@%@ : %@", retweeted_status_user.name, retweeted_status.text];
        self.retweetContentLabel.text = retweetContent;
        self.retweetContentLabel.frame = statusFrame.retweetContentLabelF;
        
        /** 被转发的微博配图 */
        if (retweeted_status.pic_urls.count) {
            self.retweetPhotoView.frame = statusFrame.retweetphotoViewF;
            self.retweetPhotoView.photos = retweeted_status.pic_urls;
            self.retweetPhotoView.hidden = NO;
        } else {
            self.retweetPhotoView.hidden = YES;
        }
    } else {
        self.retweetView.hidden = YES;
    }
    
    /** 工具条 */
    self.toolBar.frame = statusFrame.toolBarFrame;
    self.toolBar.status = status;

}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
