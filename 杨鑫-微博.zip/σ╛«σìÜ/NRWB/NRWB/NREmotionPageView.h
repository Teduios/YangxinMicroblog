//
//  NREmotionPageView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
/** 一行最多7列 */
#define NREmotionMaxClos 7

/** 一行最多7行 */
#define NRemotionMaxLin  3

//每一页的表情页数
#define NREmotionPageSize ((NREmotionMaxClos * NRemotionMaxLin) - 1)



/** 用来表示每一页的表情 1--20个表情 */

@interface NREmotionPageView : UIView
/** 每一页里面的表情 */
@property(nonatomic, strong) NSArray *emotions;

@end
