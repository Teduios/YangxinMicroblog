//
//  NRWBProfileTableViewController.m
//  微博R
//
//  Created by apple-jd42 on 15/10/30.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBProfileTableViewController.h"
#import "tableHeadView.h"

@interface NRWBProfileTableViewController ()

@end

@implementation NRWBProfileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleDone target:nil action:nil];
    self.tableView.tableHeaderView = [tableHeadView new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    if (section == 1) {
        return 1;
    }
    if (section == 2) {
        return 2;
    }
    if (section == 3) {
        return 2;
    }
    if (section == 4) {
        return 1;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ID = @"status";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Configure the cell..
    switch (indexPath.section) {
        case 0:
            break;
        case 1:
            [cell.imageView setImage:[UIImage imageNamed:@"new_friend"]];
            cell.textLabel.text = @"新的好友";
        
             break;
        case 2:
            if (indexPath.row == 0) {
                [cell.imageView setImage:[UIImage imageNamed:@"album"]];
                cell.textLabel.text = @"我的相册";
            }
            if (indexPath.row == 1) {
                [cell.imageView setImage:[UIImage imageNamed:@"like"]];
                cell.textLabel.text = @"我的赞";
            }

             break;
        case 3:
            if (indexPath.row == 0) {
                [cell.imageView setImage:[UIImage imageNamed:@"vip"]];
                cell.textLabel.text = @"微博会员";
                cell.detailTextLabel.text = @"免费体验会员";
            }
            if (indexPath.row == 1) {
                [cell.imageView setImage:[UIImage imageNamed:@"pay"]];
                cell.textLabel.text = @"微博支付";
            }
             break;
        case 4:
                [cell.imageView setImage:[UIImage imageNamed:@"draft"]];
                cell.textLabel.text = @"草稿箱";
             break;
    }


    return cell;
}



@end
