//
//  NREmotionButton.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionButton.h"

@implementation NREmotionButton

- (void)setup{
    self.titleLabel.font = [UIFont systemFontOfSize:32];
    
    //当按钮高亮时不要调整图片为灰色
    self.adjustsImageWhenHighlighted = NO;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setup];
    }
    return self;
}

//当文件从xib中或是从storyboard中创建出来时调用
- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [self setup];
    }
    return self;
}

- (void)setEmotion:(NREmotion *)emotion{
    _emotion = emotion;
    if (emotion.png) {
        [self setImage:[UIImage imageNamed:emotion.png] forState:UIControlStateNormal];
    }if(emotion.code){
        //设置emoji
        [self setTitle:[emotion.code emoji] forState:UIControlStateNormal];
        
    }

}
@end
