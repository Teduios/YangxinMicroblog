//
//  NREmotionTextView.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRTextView.h"
#import "NREmotionAttachment.h"

@interface NREmotionTextView : NRTextView
- (void)insertEmotion:(NREmotion *)emotion;

- (NSString *)fullText;
@end
