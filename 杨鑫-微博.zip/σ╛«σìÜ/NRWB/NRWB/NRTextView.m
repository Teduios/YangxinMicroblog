//
//  NRTextView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/17.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRTextView.h"

@implementation NRTextView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //UILabel
        
        //通知
        [ NRNotificationCenter addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self];
    }
    return self;
}

- (void)setPlaceholder:(NSString *)placeholder{
    _placeholder = [placeholder copy];
    [self setNeedsDisplay];
}

- (void)setPlaceholderColor:(UIColor *)placeholderColor{
    _placeholderColor = placeholderColor;
    [self setNeedsDisplay];
}

- (void)setText:(NSString *)text{
    [super text];
    [self setNeedsDisplay];
}

- (void)setFont:(UIFont *)font{
    [super setFont:font];
    [self setNeedsDisplay];
 
}

- (void)setAttributedText:(NSAttributedString *)attributedText{
    [super setAttributedText:attributedText];
    [self setNeedsDisplay];
}
- (void)dealloc{
    [NRNotificationCenter removeObserver:self];
}


/** 监听文字改变 */
- (void)textDidChange{
    
    //重绘(重新调用draw方法)，把以前画得文字删掉
    [self setNeedsDisplay];
}
- (void)drawRect:(CGRect)rect{
    
    //该方法ios7.0以前
//    [self.placeholder drawAtPoint:CGPointMake(5, 8) withFont:nil];
    
   // [self.placeholderColor set];
    
    //如果有文字就直接返回
    if (self.hasText) {
        return;
    }
    //文字的属性
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = self.font;
    attrs[NSForegroundColorAttributeName] = self.placeholderColor?self.placeholderColor:[UIColor lightGrayColor];
    
    //画文字 (文字不会自动划行)
//    [self.placeholder drawAtPoint:CGPointMake(5, 9) withAttributes:attrs];
    CGFloat x = 5;
    CGFloat w = rect.size.width - 2*x;
    CGFloat y = 8;
    CGFloat h = rect.size.height - 2 *y;
    CGRect placeholderRect = CGRectMake(x, y,w, h);
    [self.placeholder drawInRect:placeholderRect withAttributes:attrs];
    
}


@end
