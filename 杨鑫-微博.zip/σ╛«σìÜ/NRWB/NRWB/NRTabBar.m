//
//  NRTabBar.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/3.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRTabBar.h"
@interface NRTabBar ()

@property(nonatomic, weak) UIButton *plusBtn;
@end


@implementation NRTabBar

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        UIButton *plusBtn = [UIButton new];
        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        
        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add"] forState:UIControlStateNormal];
        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];
        plusBtn.size = plusBtn.currentBackgroundImage.size;
        [plusBtn addTarget:self action:@selector(plusClick) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:plusBtn];
        self.plusBtn = plusBtn;
    }
    return self;
}

//加号按钮点击事件
- (void)plusClick{
    //NSLog(@"gfgdg");
    //通知代理
    if ([self.delegate respondsToSelector:@selector(tabBarDidClickPlushButton:)]) {
        [self.delegate tabBarDidClickPlushButton:self];
    }
}


- (void)layoutSubviews{
    //一定要调用
    [super layoutSubviews];
    
    //1.设置加号按钮的位置
    self.plusBtn.centerX = self.width * 0.5;
    self.plusBtn.centerY = self.height * 0.5;
    
    //2.设置其他的tabarButton的位置和尺寸
    CGFloat tabbarButtonW = self.width / 5;
    CGFloat tabbarButtonIndex = 0;
    
    for (UIView *child in self.subviews) {
        Class class = NSClassFromString(@"UITabBarButton");
        if ([child isKindOfClass:class]) {
            //设置宽度
            child.width = tabbarButtonW;
            
            //设置x的位置
            child.x = tabbarButtonIndex * tabbarButtonW;
            
            //增加索引值
            tabbarButtonIndex ++;
            
            if (tabbarButtonIndex == 2) {
                tabbarButtonIndex ++;
            }
        }
    }
}

@end
