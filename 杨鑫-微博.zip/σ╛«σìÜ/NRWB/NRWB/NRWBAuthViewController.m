//
//  NRWBAuthViewController.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/5.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBAuthViewController.h"
#import "AFNetworking.h"
#import "MBProgressHUD+MJ.h"
#import "NRWBAccountTool.h"

@interface NRWBAuthViewController () <UIWebViewDelegate>

@end

@implementation NRWBAuthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //1.创建一个webView
    UIWebView *webView = [UIWebView new];
    webView.frame = self.view.bounds;
    webView.delegate = self;
    [self.view addSubview:webView];
    
    //2.用webView加载登陆页面(新浪提供的授权的)
    //请求地址：https://api.weibo.com/oauth2/authorize
    //https://api.weibo.com/oauth2/authorize
    //?client_id=YOUR_CLIENT_ID&response_type=code&redirect
    //请求参数
    
    NSURL *url = [NSURL URLWithString:@"https://api.weibo.com/oauth2/authorize?client_id=3791918477&redirect_uri=http://"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    
    
}

#pragma mark webView的代理

- (void)webViewDidFinishLoad:(UIWebView *)webView{
 
//    NRLog(@"webViewDidFinishLoad");
     [MBProgressHUD hideHUD];
    
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
//    NRLog(@"webViewDidStartLoad");
    [MBProgressHUD showMessage:@"正在加载"];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [MBProgressHUD hideHUD];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    //1.获得url
    NSString *url = request.URL.absoluteString;
    
    //2.判断是否为回调地址
    NSRange range = [url rangeOfString:@"code="];
    if (range.length != 0) { //是回掉地址
        //截取后面的参数
        //location位置
        NSInteger fromIndex = range.location + range.length;
        NSString *code = [url substringFromIndex:fromIndex];
//        NRLog(@"%@ %@", code, url);
        
        //理由code换取一个accessToken
        [self accessTokenWithCode:code];
        
        //禁止加载回调地址
        return NO;
    }
    
    return YES;
}

/**
 *  理由code (授权成功后的request token(标记))
 *
 *  @param code <#code description#>
 */
- (void)accessTokenWithCode:(NSString *)code{
    /*
     URL:https://api.weibo.com.oauth2/access_token
     请求参数
     client_id:申请应用分配的appkey
     client_secret:申请应用分配的AppSecret
     grant_type:使用authorization_code
     redirect_uri:授权成功后的回调地址
     code:授权成功后返回的code
     
     */
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"client_id"] = @"3791918477";
    params[@"client_secret"] = @"0ebb861fe2df7dcd6f668e6d16d01eab";
    params[@"grant_type"] = @"authorization_code";
    params[@"redirect_uri"] = @"http://";
    params[@"code"] = code;
    
    // 3.发送请求
    [mgr POST:@"https://api.weibo.com/oauth2/access_token" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        
        [MBProgressHUD hideHUD]; 
        NRLog(@"请求成功-NRNRNRNRN%@", responseObject);
        
        //将返回的账号数据-->转成模型，存入沙盒
        NRWBAccount *account = [NRWBAccount accessWithDict:responseObject];
            
        //存储账号信息
        [NRWBAccountTool saveAccount:account];
        
        //切换窗口的跟控制器
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [window switchRootViewControl];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUD];
        NRLog(@"请求失败-%@", error);
    }];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
