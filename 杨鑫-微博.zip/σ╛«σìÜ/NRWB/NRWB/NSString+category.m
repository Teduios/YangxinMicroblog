//
//  NSString+category.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/14.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NSString+category.h"

@implementation NSString (category)

- (CGSize)sizeWithfont:(UIFont *)font maxW:(CGFloat)maxW{
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = font;
    CGSize maxSize = CGSizeMake(maxW, MAXFLOAT);
    return [self boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}
- (CGSize)sizeWithfont:(UIFont *)font{
    return [self sizeWithfont:font maxW:MAXFLOAT];
}

@end
