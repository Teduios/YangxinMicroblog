//
//  NRWBStatusPhotoView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/14.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBStatusPhotoView.h"
#import "NRWBPhoto.h"
#import "NRphView.h"


@implementation NRWBStatusPhotoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //self.backgroundColor = [UIColor redColor];
    }
    return self;
}

+ (CGSize)SizeWithCount:(NSInteger)count{
    //列数
    NSInteger clos = count >=3 ? 3 : count;
    CGFloat photosW = clos * NRStatusPhotoWH + (clos - 1) * NRStatusPhotoMargin;
    
    //行数
    //    NSInteger rows = count / 3;
    //    if (count % 3 != 0) {
    //        rows = count / 3 + 1;
    //    }
    NSInteger rows = (count + 3 - 1)/3;
    CGFloat photosH = rows * NRStatusPhotoWH + (rows - 1) * NRStatusPhotoMargin;
    return  CGSizeMake(photosW, photosH);
}



- (void)setPhotos:(NSArray *)photos{
    _photos = photos;
    NSInteger photoCount = photos.count;
    while (self.subviews.count < photoCount) {
        NRphView *photoImageView = [NRphView new];
        [self addSubview:photoImageView];
    }
    
    //遍历图片控件，设置图片
    for (NSInteger i = 0; i < self.subviews.count; i++) {
        NRphView *photoImageView = self.subviews[i];

        //隐藏不需要的图片
        if (i < photoCount) { //显示图片
            photoImageView.photo = photos[i];
            photoImageView.hidden = NO;
        }else{//隐藏
            photoImageView.hidden = YES;
        }
    }
}


- (void)layoutSubviews{
    [super layoutSubviews];
    
    //设置图片的尺寸
    NSInteger photoCount = self.photos.count;
    for (NSInteger i = 0; i < photoCount; i++) {
        NRphView *photoImageView = self.subviews[i];

        
        //图片在几列
        NSInteger col = i % 3;
         photoImageView.x = col * (NRStatusPhotoWH + NRStatusPhotoMargin);
        
        ////图片在几行
        NSInteger row = i / 3;
        photoImageView.y = row * (NRStatusPhotoWH + NRStatusPhotoMargin);;
        photoImageView.width = NRStatusPhotoWH;
        photoImageView.height = NRStatusPhotoWH;
        
        
        
        
    }
}
@end
