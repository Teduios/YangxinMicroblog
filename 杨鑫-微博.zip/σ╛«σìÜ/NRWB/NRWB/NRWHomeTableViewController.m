//
//  NRWHomeTableViewController.m
//  微博R
//
//  Created by apple-jd42 on 15/10/30.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWHomeTableViewController.h"
#import "NRDropdownMenu.h"
#import "NRWBAccountTool.h"
#import "NRTitleButton.h"
#import "UIImageView+WebCache.h"
#import "NRWBStatus.h"
#import "NRStatusCell.h"
#import "NRWBStatusFrame.h"
#import "NRZhuanFaController.h"
#import "NRWBPingLunConTroller.h"

#import "HomeDetailTableViewController.h"

#import <AVFoundation/AVFoundation.h>
#import "NSString+QRCode.h"


@interface NRWHomeTableViewController () <NRDropdownMenuDelegate, AVCaptureMetadataOutputObjectsDelegate>
/**
 *  微博数组，里面存放的NRWBStatusFrame数据模型，每一个NRWBStatusFrame模型存放都是一条微博
 */
@property(nonatomic, strong) NSMutableArray *statuseFrames;

@property(nonatomic) NRStatusToolBarButtonType type;

/** 二维码输出输入的桥梁 */
@property(nonatomic, strong) AVCaptureSession *session;

/** 把摄像头显示早界面上得layer */
@property(nonatomic, strong) AVCaptureVideoPreviewLayer *layer;

@end

@implementation NRWHomeTableViewController

- (NSMutableArray *)statuseFrames{
    if (!_statuseFrames) {
        _statuseFrames = [NSMutableArray new];
    }
    return _statuseFrames;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellEditingStyleNone;
    
    self.tableView.backgroundColor = NRWColor(211, 211, 211);
    //self.tableView.contentInset = UIEdgeInsetsMake(15, 0, 0, 0);
    //https://api.weibo.com/2/users/show.json
    //设置导航栏的内容
    [self setupNav];
    
    //获取用户的信息 (昵称)
    [self setupUserInfo];
 
    //继承刷新控件
    //[self setupRefresh];
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.tableView.header endRefreshing];
        [self refreshStateChange];
        [self.tableView reloadData];
      
    }];
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self getMoreData];
        [self.tableView reloadData];
        [self.tableView.footer endRefreshing];
    }];
    
    
    [self.tableView.header beginRefreshing];
    
//    //获得未读微博数
//    NSTimer *timer =  [NSTimer scheduledTimerWithTimeInterval:60 target:self selector:@selector(setupUnreadCount) userInfo:nil repeats:YES];
//    
//    //主线程也会抽一点时间处理timer（不管主线程是否在处理其他事件）
//    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    
    
    //监听转发按钮选中的通知
    [NRNotificationCenter addObserver:self selector:@selector(statusBtnDidSelected:) name:NRStatusBtnDidSelectedNotification object:nil];
    
    //监听评论按钮选中的通知
    [NRNotificationCenter addObserver:self selector:@selector(statusBtnPingLun:) name:NRStatusBtnPingLunNotification object:nil];
    
    
   
}

/** 获得未读取的微博 */
- (void)setupUnreadCount{
    //1.请求管理者
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    //2.拼接请求的参数
    NRWBAccount *account = [NRWBAccountTool account];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    params[@"uid"] = account.uid;
    
    //3.发送请求
    [manager GET:@"https://rm.api.weibo.com/2/remind/unread_count.json" parameters:params success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        //微博的未读数
        NSString *status = [responseObject[@"status"] description];
        
        //设置提醒数字
        if ([status isEqualToString:@"0"] ) {
            self.tabBarItem.badgeValue = nil;
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        }else{
           self.tabBarItem.badgeValue = [NSString stringWithFormat:@"%@", status];
            
           // [@"iOS" stringByAppendingString\
             :[UIDevice currentDevice].systemVersion]
            
            if ([UIDevice currentDevice].systemVersion.floatValue > 8.0) {
                UIUserNotificationSettings *setTing = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge categories:nil];
                [[UIApplication sharedApplication] registerUserNotificationSettings:setTing];
            }
             [UIApplication sharedApplication].applicationIconBadgeNumber = status.intValue;
        }
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        NRLog(@"请求失败-%@", error);
    }];
}

/**
 *继承刷新控件
 */
- (void)setupRefresh{
    UIRefreshControl *control = [UIRefreshControl new];
    //监听刷新事件
   // [control addTarget:self action:@selector(refreshStateChange:) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:control];
    
    //马上进入刷新状态
    [control beginRefreshing];
    
    //马上记载数据
   // [self refreshStateChange:control];
}

/** NRWBStatus模型转化为NRWBStatusFrame模型 */
- (NSArray *)statusFramesWithStatuses:(NSArray *)statuses{
    NSMutableArray *frames = [NSMutableArray array];
    for (NRWBStatus *status in statuses) {
        NRWBStatusFrame *sFrame = [NRWBStatusFrame new];
        sFrame.status = status;
        [frames addObject:sFrame];
    }
    return frames;
}


/**
 *  脚步加载更多数据
 */
- (void)getMoreData{
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NRWBAccount *account = [NRWBAccountTool account];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    
    //取出后面的微博(曾经刷新过的微博的id)
    NRWBStatusFrame *lastStatusFrame = [self.statuseFrames lastObject];
    if (lastStatusFrame) {
        long long maxId = lastStatusFrame.status.idstr.longLongValue - 1;
        
        params[@"max_id"] = @(maxId) ;
        
    }
    // 3.发送请求
    [mgr GET:@"https://api.weibo.com/2/statuses/friends_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        NSArray *lastStatuses = [NRWBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        NSArray *lastFrames = [self statusFramesWithStatuses:lastStatuses];
        
        [self.statuseFrames addObjectsFromArray:lastFrames];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NRLog(@"请求失败 %@", error);
        //结束刷新
        // [control endRefreshing];
    }];

}

/**
 *  进入刷新状态 
 */
//- (void)refreshStateChange:(UIRefreshControl *)control{
- (void)refreshStateChange{
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NRWBAccount *account = [NRWBAccountTool account];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    
    //取出最前的微博(最新的微博，ID最大的微博)
    NRWBStatusFrame *firstStatusFrame = [self.statuseFrames firstObject];
    if (firstStatusFrame) {
        params[@"since_id"] = firstStatusFrame.status.idstr;

    }
    // 3.发送请求
    [mgr GET:@"https://api.weibo.com/2/statuses/friends_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
        NSArray *newStatuses = [NRWBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        //将 "NRWBStatus数组" 转为 NRWBStatusFrame数组
        NSArray *newFrames = [self statusFramesWithStatuses:newStatuses];
        //将最新的微博数据添加到总数组的最前面
        //两个参数：位置：范围(多长)
        NSRange rang = NSMakeRange(0, newFrames.count);
        NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:rang];
        [self.statuseFrames insertObjects:newFrames atIndexes:set];
        //刷新表格
        [self.tableView reloadData];
        
        //结束刷新
        //[control endRefreshing];
        
        //显示最新微博数量
        [self showNewStatusCount:newStatuses.count];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NRLog(@"请求失败 %@", error);
        //结束刷新
       // [control endRefreshing];
    }];

}

- (void)showNewStatusCount:(NSInteger)count{
    
    //刷新成功清空图标指示未读微博数
    self.tabBarItem.badgeValue = nil;
     [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    //创建label
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_new_status_background"]];
    label.width = [UIScreen mainScreen].bounds.size.width;
    label.height = 35;
    
    //设置其他属性
    if (count == 0) {
         label.text = @"没有最新微博数据";
    }else{
        label.text = [NSString stringWithFormat:@"共有%ld条的微博数据", count];
    }
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:16];
    label.textAlignment = NSTextAlignmentCenter;
    
    //添加[];
    label.y = 64 - label.height;
    //[self.navigationController.view addSubview:label];
    [self.navigationController.view insertSubview:label belowSubview:self.navigationController.navigationBar];
    
    //让label往下走
    //动画时间
    CGFloat druation =0.5;
    
    //动画万还有事做
    [UIView animateWithDuration:druation animations:^{
//        label.y += label.height;
         label.transform = CGAffineTransformMakeTranslation(0, label.height);
    } completion:^(BOOL finished) {
        CGFloat delay = 1.0;
        //UIViewAnimationOptionCurveLinear匀速
        [UIView animateWithDuration:druation delay:delay options:UIViewAnimationOptionCurveLinear animations:^{
//            label.y -= label.height;
            //回到原来的位置
            label.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            [label removeFromSuperview];
        }];
    }];
}

/**
  *获取用户的信息
  */

- (void)setupUserInfo{
    //https://api.weibo.com/2/users/show.json
//    access_token	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
//    uid	false	int64	需要查询的用户ID。
    
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NRWBAccount *account = [NRWBAccountTool account];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = account.access_token;
    params[@"uid"] = account.uid;
    
    // 3.发送请求
    [mgr GET:@"https://api.weibo.com/2/users/show.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
       // NRLog(@"请求成功 %@", responseObject);
        
        //设置标题按钮的文字
        UIButton *titleButton = (UIButton *)self.navigationItem.titleView;

        NRWBUser *user = [NRWBUser objectWithKeyValues:responseObject];
        //NSString *name = responseObject[@"name"];
              [titleButton setTitle:user.name forState:UIControlStateNormal];
        
        //存储昵称到沙盒里
        account.name = user.name;
        [NRWBAccountTool saveAccount:account];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
       NRLog(@"请求失败 %@", error);
    }];

}
/**
  *设置导航栏的内容
  */
- (void)setupNav{
    //设置导航栏上得位置
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self Action:@selector(friendsearch) image:@"navigationbar_friendsearch" highImage:@"navigationbar_friendsearch_highlighted"];
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTarget:self Action:@selector(popNRQRCode) image:@"navigationbar_pop" highImage:@"navigationbar_pop_highlighted"];
    
    //设置中间的标题
    NRTitleButton *titleBtn = [NRTitleButton new];
    
    //设置图片和文字
    NSString *name = [NRWBAccountTool account].name;
    
    [titleBtn setTitle:name?name:@"首页" forState:UIControlStateNormal];
    
    //监听标题点击
    [titleBtn addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    self.navigationItem.titleView = titleBtn;
    //如果图片的某个方向上有凸起，那么这个方向不能拉伸
}

/**
 标题点击
 */
- (void)titleClick:(UIButton *)titleBtn{
    //1.创建下拉菜单
    NRDropdownMenu *menu =[NRDropdownMenu menu];
    menu.delegate = self;
    
//    menu.content = [UIButton buttonWithType:UIButtonTypeContactAdd];
    //2.设置下拉菜单的内容
    menu.content = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 100, 200)];
    
    //3.显示
    [menu showFromView:titleBtn];
    
    
}

- (void)friendsearch{
    NSLog(@"dsfd");
    
}

/* 扫描二维码 */
- (void)popNRQRCode{
    
    NSLog(@"78789898789");
    //获取摄像设备
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    //创建输入流
    AVCaptureDeviceInput *inputer = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    
    //创建输出流
    AVCaptureMetadataOutput *output = [AVCaptureMetadataOutput new];
    
    //设置代理，在主线程中刷新
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    //初始化输入输出对象
    _session = [AVCaptureSession new];
    
    //设置高质量的传输
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    
    //设置输入流
    [_session addInput:inputer];
    
    //设置输出流
    [_session addOutput:output];
    
    //设置扫描
    output.metadataObjectTypes = @[AVMetadataObjectTypeQRCode,
                                   AVMetadataObjectTypeEAN13Code,
                                   AVMetadataObjectTypeEAN8Code,
                                   AVMetadataObjectTypeCode128Code];
    
    //把session的画面读出来
    self.layer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    
    //设置满屏显示
    self.layer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    
    //设置layer的大小
    self.layer.frame = self.view.bounds;
    [self.view.layer addSublayer:self.layer];
    
    //启动扫描
    [_session startRunning];
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects.count > 0) {
        AVMetadataMachineReadableCodeObject *obj = metadataObjects[0];
        [_session stopRunning];
        [self.layer  removeFromSuperlayer];
        //[self showSuccessMsg:obj.stringValue];
        NSLog(@"扫描结果 %@", obj.stringValue);
    }
}




#pragma mark - NRDropdownmenu

//显示下拉菜单
- (void)dropdownMenuDidShow:(NRDropdownMenu *)menu{
    UIButton *titleBtn =  (UIButton *)self.navigationItem.titleView;
    //4.让箭头向上
    //[titleBtn setImage:[UIImage imageNamed:@"navigationbar_arrow_up"] forState:UIControlStateNormal];
    titleBtn.selected = YES;
}

//下拉菜单销毁
- (void)dropdownMenuDidDismiss:(NRDropdownMenu *)menu{
    UIButton *titleBtn =  (UIButton *)self.navigationItem.titleView;
    //4.让箭头向下
    //[titleBtn setImage:[UIImage imageNamed:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
    titleBtn.selected = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.statuseFrames.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //创建cell
    NRStatusCell *cell = [NRStatusCell cellWithTableView:tableView];
    
    //给cell传递模型数据
    cell.statusFrame = self.statuseFrames[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    HomeDetailTableViewController *vc = [HomeDetailTableViewController new];
    vc.statusFrame = self.statuseFrames[indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
    
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //scrollView == self.tableView == self.view
    //如果tableView还没有数据，就直接返回
    if (self.statuseFrames.count == 0 || self.tableView.tableFooterView.isHidden == NO) {
        return;
    }
    
    CGFloat offsetY = scrollView.contentOffset.y;
    
    //当最后一个cell完全显示在眼前时contentOffset的y值
    CGFloat judegOffsetY = scrollView.contentSize.height + scrollView.contentInset.bottom - scrollView.height - self.tableView.tableFooterView.height;
    
    if (offsetY > judegOffsetY) {
        self.tableView.tableFooterView.hidden = NO;
        
        //加载更多地微博数据
        [self getMoreData];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NRWBStatusFrame *f = self.statuseFrames[indexPath.row];
    return f.cellHeight;
}

- (void)statusBtnDidSelected:(NSNotification *)notification{
    NRZhuanFaController *vc = [NRZhuanFaController new];
    NRWBStatus *status =  notification.userInfo[NRStatusBtnkey];
    
    vc.statue = status;
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)statusBtnPingLun:(NSNotification *)notification{
    NRWBPingLunConTroller *vc = [NRWBPingLunConTroller new];
    NRWBStatus *status =  notification.userInfo[NRStatusBtnPingLunkey];
    
    vc.statue = status;
    [self.navigationController pushViewController:vc animated:YES];

    
}

@end
