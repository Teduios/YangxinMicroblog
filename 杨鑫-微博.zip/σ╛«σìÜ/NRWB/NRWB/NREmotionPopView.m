//
//  NREmotionPopView.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/20.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionPopView.h"
#import "NREmotionButton.h"

@interface NREmotionPopView ()
@property (weak, nonatomic) IBOutlet NREmotionButton *emotionButton;

@end

@implementation NREmotionPopView

+ (instancetype)popView{
    return [[NSBundle mainBundle] loadNibNamed:@"NREmotionPopView" owner:nil options:nil].lastObject;
}

- (void)showFrom:(NREmotionButton *)btn{
    
    if (btn == nil) {
        return;
    }
    //获得按钮绑定的表情
    //NREmotion *emotion = btn.emotion;
    
    //给popView传数据
    self.emotionButton.emotion = btn.emotion;
    //取得最上面的窗口
    UIWindow *window =  [[UIApplication sharedApplication].windows lastObject];
    [window addSubview:self];
    
    //被点击的按钮在窗口(window)的位置
    CGRect btnFrame =  [btn convertRect:btn.bounds toView:window];
    
    self.y = CGRectGetMidY(btnFrame) - self.height;
    self.centerX = CGRectGetMidX(btnFrame);

}
@end
