//
//  NRWBStatusFrame.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/11.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NRWBStatus.h"

/** cell的变宽 */
#define kStatusCellBordeeW 10

#define kStatusCellMarginW 8

/** 昵称字体 */
#define kStatusCellNameFont [UIFont systemFontOfSize:14]

/** 时间字体 */
#define kStatusCellTimeFont [UIFont systemFontOfSize:12]

/** 来源字体 */
#define kStatusCellSourceFont kStatusCellTimeFont

/** 正文字体 */
#define kStatusCellTextFont [UIFont systemFontOfSize:15]

/** 被转发微博正文字体 */
#define kStatusCellRetweetTextFont [UIFont systemFontOfSize:13]


@interface NRWBStatusFrame:NSObject
@property(nonatomic, strong) NRWBStatus *status;

/** 原创微博整体 */
@property(nonatomic, assign) CGRect originalViewFrame;

/** 头像 */
@property(nonatomic, assign) CGRect iconViewFrame;

/** 会员图标 */
@property(nonatomic, assign) CGRect vipViewFrame;

/** 配图 */
@property(nonatomic, assign) CGRect photoViewFrame;

/** 昵称 */
@property(nonatomic, assign) CGRect nameLabelFrame;

/** 来源 */
@property(nonatomic, assign) CGRect sourceLabelFrame;

/** 发微博的时间 */
@property(nonatomic, assign) CGRect timeLabelFrame;

/** 正文 */
@property(nonatomic, assign) CGRect contentLabelFrame;

/** 转发微博整体 */
@property(nonatomic, assign) CGRect retweetViewF;

/** 昵称 + 转发正文  */
@property(nonatomic, assign) CGRect retweetContentLabelF;

/** 转发配图 */
@property(nonatomic, assign) CGRect retweetphotoViewF;

/** 底部工具条 */
@property(nonatomic, assign) CGRect toolBarFrame;


@property (nonatomic, assign)CGFloat cellHeight;
@end
