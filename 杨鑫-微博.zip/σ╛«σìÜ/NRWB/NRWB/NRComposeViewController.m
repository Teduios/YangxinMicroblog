//
//  NRComposeViewController.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/17.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRComposeViewController.h"
#import "NRWBAccountTool.h"
#import "NRComposeToolBar.h"
#import "NRComposePhotosView.h"
#import "NREmotionkeuboard.h"
#import "NREmotion.h"
#import "NREmotionTextView.h"


@interface NRComposeViewController () <UITextViewDelegate, NRComposeToolBarDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
/** 存放拍照或相册中选好的图片 */
@property(nonatomic, strong) NRComposePhotosView *photosView;

/** 输入控件 */
@property(nonatomic, strong) NREmotionTextView *textView;
@property(nonatomic, strong) NRComposeToolBar *toolbar;

/** 表情键盘 */
@property(nonatomic, strong) NREmotionkeuboard *emotionKeyboard;

/** 是否正在切换键盘 */
@property(nonatomic) BOOL switchingKeybaord;
@end

@implementation NRComposeViewController
#pragma mark - 懒加载
- (NREmotionkeuboard *)emotionKeyboard{
    if (!_emotionKeyboard) {
        _emotionKeyboard = [NREmotionkeuboard new];
        _emotionKeyboard.width = self.view.width;
        _emotionKeyboard.height = 216;
    }
    return _emotionKeyboard;
}



#pragma mark - 系统方法
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //默认YES，当scrollView遇到UINavigationBar、UIBar控件时，默认会设置scrollview的contentInset
    //self.automaticallyAdjustsScrollViewInsets;
    
    //设置导航栏
    [self setupNav];
    
    //添加输入控件
    [self setupTextView];
    
    //添加工具条
    [self setupToolBar];
    
    
    //添加工相册
    [self setupPhotosView];
}

- (void)dealloc{
    [NRNotificationCenter removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    //让textView成为第一响应者,默认直接弹起键盘
    [self.textView becomeFirstResponder];
}

#pragma mark- 初始方法

- (void)setupPhotosView{
    self.photosView = [NRComposePhotosView new];
    self.photosView.y = 100;
    self.photosView.width = self.view.width;
    self.photosView.height = self.view.height;
    [self.textView addSubview:self.photosView];
}

/** 添加工具条 */
- (void)setupToolBar{
    self.toolbar = [NRComposeToolBar new];
    self.toolbar.width = self.view.width;
    self.toolbar.height = 44;
    self.toolbar.y = self.view.height - self.toolbar.height;

    self.toolbar.delegate = self;
    //显示在键盘上得工具条
    //self.textView.inputAccessoryView = toolBar;
    [self.view addSubview:self.toolbar];
    
    // self.textView.inputView 设置键盘的
    //self.textView.inputView = [UIButton buttonWithType:UIButtonTypeContactAdd];
}

/** 添加输入控件 */
- (void)setupTextView{
    self.textView = [[NREmotionTextView alloc]init];
    
    self.textView.delegate = self;
    
    //允许垂直方向上永远可以拖拽 (弹簧效果)
    self.textView.alwaysBounceVertical = YES;
    
    self.textView.frame = self.view.bounds;
    self.textView.font= [UIFont systemFontOfSize:20];
    self.textView.placeholder = @"分享你的新鲜事....";
    //    self.textView.placeholderColor = [UIColor redColor];
    
    [self.view addSubview:self.textView];
    
    
    
    
    //监听文字改变通知
    [NRNotificationCenter addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self.textView];
    
    
    //监听键盘弹起通知
    [NRNotificationCenter addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //监听表情选中的通知
    [NRNotificationCenter addObserver:self selector:@selector(emotionDidSelected:) name:NREmotionDidSelectedNotification object:nil];
    
    //删除文字的通知
    [NRNotificationCenter addObserver:self selector:@selector(emotionDidDelete) name:NREmotionDidDeleteNotification object:nil];

}



/** 设置导航栏 */
- (void)setupNav{
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(cancle)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(send)];

    //按钮不能点击
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
    NSString *name = [NRWBAccountTool account].name;
    NSString *prefix = @"发微博";
    if (name) {
        UILabel *titleView = [UILabel new];
        titleView.width = 200;
        titleView.height = 45;
        titleView.numberOfLines = 0;
        //titleView.backgroundColor = [UIColor redColor];
        titleView.textAlignment = NSTextAlignmentCenter;
        NSString *str = [NSString stringWithFormat:@"%@\n%@", prefix, name];
        //有样式的文字 (创建一个带有属性的字符串【比如文字的颜色，字体】)
        NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:str];
        
        //添加属性
        [attrStr addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:16] range:[str rangeOfString:prefix]];
        [attrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:[str rangeOfString:name]];
        
        
        titleView.attributedText = attrStr;
        
        self.navigationItem.titleView = titleView;

    }else{
        self.title = prefix;
    }
    
}

#pragma mark - 监听方法
//删除表情
- (void)emotionDidDelete{
    //往回删
    [self.textView deleteBackward];
}

//表情被选中
- (void)emotionDidSelected:(NSNotification *)notification{
    NREmotion *emotion =  notification.userInfo[NRemotionkey];
    
    [self.textView insertEmotion:emotion];
}


/** 当键盘的frame改变时就调用 */
- (void)keyboardWillChangeFrame:(NSNotification *)notification{
    
   // 如果正在切换键盘就不然工具条动
    if (self.switchingKeybaord) {
        return;
    }
    NSDictionary *userInfo = notification.userInfo;
    
    //动画的时间
    double duration = [userInfo[UIKeyboardAnimationCurveUserInfoKey] doubleValue];
    
    //键盘的frame
    CGRect keyboardF = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    [UIView animateWithDuration:duration animations:^{
//        if (CGRectGetMaxY(self.toolbar.frame) >= self.view.height) {
//            self.toolbar.y = self.view.height - self.toolbar.height;
//        }else{
//             self.toolbar.y = keyboardF.origin.y - self.toolbar.height;
//        }
        if (keyboardF.origin.y > self.view.height) { //键盘的y已经超过控制器的高了
            self.toolbar.y = self.view.height - self.toolbar.height;
        }else{
            self.toolbar.y = keyboardF.origin.y - self.toolbar.height;
        }
        
    }];
}

//取消发送微博
- (void)cancle{
    [self dismissViewControllerAnimated:YES completion:nil];
}


//发送微博
- (void)send{
    
    if (self.photosView.photos.count) { //发送带有图片的微博
        [self sendWithImage];
    }else{
        [self sendWithOutImage];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

/**
 *  发送有图片的微博
 */
- (void)sendWithImage{
    //发微博的URL：https://api.weibo.com/2/statuses/upload.json
    //参数
    //access_token	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
    //status	true	string	要发布的微博文本内容，必须做URLencode，内容不超过140个汉字。
    //pic 微博的图片
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [NRWBAccountTool account].access_token;
    params[@"status"] = self.textView.fullText;
    
    
    //先获得图片
    //发送请求
    [mgr POST:@"https://api.weibo.com/2/statuses/upload.json" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        UIImage *image = [self.photosView.photos firstObject];
        NSData *data = UIImageJPEGRepresentation(image, 1.0);
        [formData appendPartWithFileData:data name:@"pic" fileName:@"test.jpg" mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [MBProgressHUD showSuccess:@"微博发送成功"];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        [MBProgressHUD showError:@"微博发送失败"];
    }];
    

}

/**
 *  发送无图片的微博
 */
- (void)sendWithOutImage{
    //发微博的URL：https://api.weibo.com/2/statuses/update.json
    //参数
    //access_token	false	string	采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
    //status	true	string	要发布的微博文本内容，必须做URLencode，内容不超过140个汉字。
    //pic 微博的图片
    //1.请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //2.拼接请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"access_token"] = [NRWBAccountTool account].access_token;
    params[@"status"] = self.textView.fullText;
 
    //只能发有文字的微博
    // 3.发送请求
        [mgr POST:@"https://api.weibo.com/2/statuses/update.json" parameters:params success:^(AFHTTPRequestOperation *operation, NSDictionary *responseObject) {
            [MBProgressHUD showSuccess:@"微博发送成功"];
    
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [MBProgressHUD showError:@"微博发送失败"];
        }];
}

//监听textView的文字改变
- (void)textDidChange{
    self.navigationItem.rightBarButtonItem.enabled = self.textView.hasText;
}


#pragma mark - 代理方法UItextViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}

#pragma mark -NRComposeToolBarDelegate 
- (void)composeToolBar:(NRComposeToolBar *)toolBar didClickButton:(NRComposeToolBarButtonType)type{
    switch (type) {
        case NRComposeToolBarButtonTypeCamera: { //相机
            [self openCamera];
            break;
        }
        case NRComposeToolBarButtonTypePicture: {//相册
            [self openAlbum];
            break;
        }
        case NRComposeToolBarButtonTypeMention: {//@
            
            break;
        }
        case NRComposeToolBarButtonTypeTrend: {//#
            
            break;
        }
        case NRComposeToolBarButtonTypeEmotion: {//表情
            [self switchKeybord];
            
            break;
        }
        default: {
            break;
        }
    }
}

#pragma mark - switch里面调用的方法(私有的方法)

/** 切换表情键盘 */
- (void)switchKeybord{
    if (self.textView.inputView == nil) {
        self.textView.inputView = self.emotionKeyboard;
        
        //显示键盘图标
        self.toolbar.showEmotionButton = NO;
    }else{
        
        //默认为空，弹出系统自带的键盘
        self.textView.inputView = nil;
        
        //显示表情图标
        self.toolbar.showEmotionButton = YES;
    }
    
    //开始切换键盘
    self.switchingKeybaord = YES;
    
    
    //退出键盘
    [self.textView endEditing:YES];
    /**
     [self.view endEditing:YES];
     [self.view.window endEditing:YES];
     [self.textView resignFirstResponder];
     */
    //结束切换键盘
    self.switchingKeybaord = NO;
   
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //弹出键盘
        [self.textView becomeFirstResponder];
    });
   
}


/** 打开系统相机 */
- (void)openCamera{
    //可能照相也可能是相册里面的
    [self openImagePickerController:UIImagePickerControllerSourceTypeCamera];
}

/** 打开系统相册 */
- (void)openAlbum{
    
    
    //如果想自己写一个图片选择控制器，得利用AssetLibrary.framework利用这个框架可以获得手机上得所有图片
    [self openImagePickerController:UIImagePickerControllerSourceTypePhotoLibrary];
}

- (void)openImagePickerController:(UIImagePickerControllerSourceType)type{
    
    //相机不可用返回
    if (![UIImagePickerController isSourceTypeAvailable:type]) {
        return;
    }
    
    UIImagePickerController *ipc = [UIImagePickerController new];
    
    //可能照相也可能是相册里面的
    ipc.sourceType = type;
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:nil];
}

#pragma mark - <UINavigationControllerDelegate, UIImagePickerControllerDelegate>

//选择完毕 (选择完图片《拍照完毕或从相册选择完毕》)
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    //在info中选择图片
    UIImage *image =  info[UIImagePickerControllerOriginalImage];
    
    //添加图片到photosView
    [self.photosView addPhoto:image];
}


@end
