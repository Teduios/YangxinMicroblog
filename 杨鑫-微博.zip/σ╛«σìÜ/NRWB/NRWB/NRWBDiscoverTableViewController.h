//
//  NRWBDiscoverTableViewController.h
//  微博R
//
//  Created by apple-jd42 on 15/10/30.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NRWBDiscoverTableViewController : UITableViewController

@end
