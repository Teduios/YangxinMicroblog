//
//  HomeDetailTableViewController.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/23.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NRWBStatusFrame.h"
#import "NRWBStatus.h"

@interface HomeDetailTableViewController : UITableViewController
@property(nonatomic, strong) NRWBStatusFrame *statusFrame;
@end
