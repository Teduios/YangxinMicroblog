//
//  NREmotionkeuboard.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/19.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NREmotionkeuboard.h"
#import "NREmotion.h"
#import "MJExtension.h"
#import "NREmotionTool.h"

@interface NREmotionkeuboard () <NREmotionTabBarDelegate>
/** 正在显示的listView */
@property(nonatomic, strong)  NREmotionalListView *showListView;

/** 表情内容 */
@property(nonatomic, strong)  NREmotionalListView *recentListView;
@property(nonatomic, strong)  NREmotionalListView *defaultListView;
@property(nonatomic, strong)  NREmotionalListView *emojiListView;
@property(nonatomic, strong)  NREmotionalListView *lxhListView;
/** 表情键盘的tabbar */
@property(nonatomic, strong) NREmotionTabBar *tabBar;
@end
@implementation NREmotionkeuboard

#pragma mark - 懒加载
-(NREmotionalListView *)recentListView{
    if (!_recentListView) {
        _recentListView = [NREmotionalListView new];
        //加载沙盒里面的数据
        _recentListView.emotions = [NREmotionTool recentEmotions];
    }
    return _recentListView;
}
- (NREmotionalListView *)defaultListView{
    if (!_defaultListView) {
        _defaultListView = [NREmotionalListView new];
//        _defaultListView.backgroundColor = [UIColor redColor];
        NSString *path =  [[NSBundle mainBundle] pathForResource:@"EmotionIcons/default/info.plist" ofType:nil];
        
        _defaultListView.emotions = [NREmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    return _defaultListView;
}

- (NREmotionalListView *)emojiListView{
    if (!_emojiListView) {
        _emojiListView = [NREmotionalListView new];
//        _emojiListView.backgroundColor = [UIColor yellowColor];
        NSString *path =  [[NSBundle mainBundle] pathForResource:@"EmotionIcons/emoji/info.plist" ofType:nil];
        
        _emojiListView.emotions = [NREmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
        

    }
    return _emojiListView;
}

- (NREmotionalListView *)lxhListView{
    if (!_lxhListView) {
        _lxhListView = [NREmotionalListView new];
//        _lxhListView.backgroundColor = [UIColor greenColor];
        NSString *path =  [[NSBundle mainBundle] pathForResource:@"EmotionIcons/lxh/info.plist" ofType:nil];
        
        _lxhListView.emotions = [NREmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    return _lxhListView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //表情键盘的tabbar
        self.tabBar = [NREmotionTabBar new];
        [self addSubview:self.tabBar];
        self.tabBar.delegate = self;
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    
    //1.tabbar
    self.tabBar.height = 37;
    self.tabBar.width = self.width;
    self.tabBar.x = 0;
    self.tabBar.y = self.height - self.tabBar.height;
    
    //
    self.showListView.x = self.showListView.y = 0;
    self.showListView.width = self.width;
    self.showListView.height = self.tabBar.y;
    
}

#pragma mark - NREmotionTabBarDelegate
- (void)emotionTabBar:(NREmotionTabBar *)tabBar didSelectButton:(NREmotionTabBarBtnType)btnType{
    
   //移除正在显示的
    [self.showListView removeFromSuperview];
    
    switch (btnType) {
        case NREmotionTabBarBtnTypeRecent: { //最近
            [self addSubview:self.recentListView];
            break;
        }
        case NREmotionTabBarBtnTypeDefault: { //默认
            [self addSubview:self.defaultListView];
            break;
        }
        case NREmotionTabBarBtnTypeEmoji: { //Emoj
            [self addSubview:self.emojiListView];
            break;
        }
        case NREmotionTabBarBtnTypeLXH: { //浪小花
            [self addSubview:self.lxhListView];
            break;
        }
        default: {
            break;
        }
    }
    
    self.showListView = [self.subviews lastObject];
    //设置frame
    [self setNeedsLayout];
}

@end
