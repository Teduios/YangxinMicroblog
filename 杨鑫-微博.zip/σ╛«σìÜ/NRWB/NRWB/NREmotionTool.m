//
//  NREmotionTool.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/21.
//  Copyright © 2015年 NRYX. All rights reserved.
//

//最进表情的存储路径
#define NRWBRecentEmotionPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject  stringByAppendingPathComponent:@"emotions.archive"]

#import "NREmotionTool.h"

@implementation NREmotionTool
//将表情存入沙盒
+ (void)addRecentEmotion:(NREmotion *)emotion{
    
    //加载沙盒里面的表情数据
    NSMutableArray *emotions = (NSMutableArray *)[self recentEmotions];
    if (emotions == nil) {
        emotions = [NSMutableArray array];
    }

    //把新使用的表情放到数组的最前面
    [emotions insertObject:emotion atIndex:0];
    
    //将数据存入沙盒里
    [NSKeyedArchiver archiveRootObject:emotions toFile:NRWBRecentEmotionPath];
    
}

//从文件读取装有表情的数组
+ (NSArray *)recentEmotions{
    return [NSKeyedUnarchiver unarchiveObjectWithFile:NRWBRecentEmotionPath];
}
@end
