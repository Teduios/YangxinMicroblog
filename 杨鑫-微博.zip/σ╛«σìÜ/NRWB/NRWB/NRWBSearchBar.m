//
//  NRWBSearchBar.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/2.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRWBSearchBar.h"

@implementation NRWBSearchBar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.font = [UIFont systemFontOfSize:15];
        self.placeholder = @"请输入要搜索的内容";
        self.background = [UIImage imageNamed:@"searchbar_textfield_background"];
        
        //设置搜索框上面的放大镜
        UIImageView *searchIcon = [UIImageView new];
        searchIcon.image = [UIImage imageNamed:@"searchbar_textfield_search_icon"];
        searchIcon.width = 30;
        searchIcon.height = 30;
        searchIcon.contentMode = UIViewContentModeCenter;
        self.leftView = searchIcon;
        self.leftViewMode = UITextFieldViewModeAlways;
    }
    return self;
}

+ (instancetype)searchBar{
    return [[self alloc] init];
}

@end
