//
//  NRWBStatus.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/7.
//  Copyright © 2015年 NRYX. All rights reserved.
//
//微博模型
/**
 *  idstr	string	字符串型的微博ID
 text	string	微博信息内容
 source	string	微博来源
 favorited	boolean	是否已收藏，true：是，false：否
 truncated	boolean	是否被截断，true：是，false：否
 in_reply_to_status_id	string	（暂未支持）回复ID
 in_reply_to_user_id	string	（暂未支持）回复人UID
 in_reply_to_screen_name	string	（暂未支持）回复人昵称
 thumbnail_pic	string	缩略图片地址，没有时不返回此字段
 bmiddle_pic	string	中等尺寸图片地址，没有时不返回此字段
 original_pic	string	原始图片地址，没有时不返回此字段
 geo	object	地理信息字段 详细
 user	object	微博作者的用户信息字段 详细
 retweeted_status	object	被转发的原微博信息字段，当该微博为转发微博时返回 详细
 */

#import <Foundation/Foundation.h>
#import "NRWBUser.h"

@interface NRWBStatus : NSObject
/** idstr	string	字符串型的微博ID */
@property(nonatomic, strong) NSString *idstr;

/** text	string	微博信息内容 */
@property(nonatomic, strong) NSString *text;

/** user	object	微博作者的用户信息字段 详细 */
@property(nonatomic, strong) NRWBUser *user;

/** 微博的创建时间 */
@property(nonatomic, strong) NSString *created_at;

/** 微博来源 */
@property(nonatomic, copy) NSString *source;

/** 存放配图的数组, 没有图片为空 */
@property(nonatomic, strong) NSArray *pic_urls;

/** 转发的微博 */
@property(nonatomic, strong) NRWBStatus *retweeted_status;

/*
 reposts_count	int	转发数
 comments_count	int	评论数
 attitudes_count	int	表态数
 */
/** 转发数 */
@property(nonatomic) NSInteger reposts_count;

/** 评论数 */
@property(nonatomic) NSInteger comments_count;

/** 表态数 （是否点赞） */
@property(nonatomic) NSInteger attitudes_count;

@end
