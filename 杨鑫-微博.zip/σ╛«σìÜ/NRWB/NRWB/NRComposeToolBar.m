//
//  NRComposeToolBar.m
//  NRWB
//
//  Created by apple-jd42 on 15/11/18.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import "NRComposeToolBar.h"
@interface NRComposeToolBar()
@property(nonatomic, strong) UIButton *emotionBtn;
@end

@implementation NRComposeToolBar

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"compose_toolbar_background"]];
        
        //相机
        [self setupBtn:@"compose_camerabutton_background" highImage:@"compose_camerabutton_background_highlighted" type:NRComposeToolBarButtonTypeCamera];
        
        //相册
        [self setupBtn:@"compose_toolbar_picture" highImage:@"compose_toolbar_picture_highlighted" type:NRComposeToolBarButtonTypePicture];
        
        //@
        [self setupBtn:@"compose_mentionbutton_background" highImage:@"compose_mentionbutton_background_highlighted" type:NRComposeToolBarButtonTypeMention];
        
        //#
        
          [self setupBtn:@"compose_trendbutton_background" highImage:@"compose_trendbutton_background_highlighted" type:NRComposeToolBarButtonTypeTrend];
        
        //表情
       self.emotionBtn = [self setupBtn:@"compose_emoticonbutton_background" highImage:@"compose_emoticonbutton_background_highlighted" type:NRComposeToolBarButtonTypeEmotion];
        
        
      
    }
    return self;
}

- (void)setShowEmotionButton:(BOOL)showEmotionButton{
    _showEmotionButton = showEmotionButton;
    if (showEmotionButton) {
        [self.emotionBtn setImage:[UIImage imageNamed:@"compose_emoticonbutton_background"] forState:UIControlStateNormal];
        [self.emotionBtn setImage:[UIImage imageNamed:@"compose_emoticonbutton_background_highlighted"] forState:UIControlStateHighlighted];
    }else{
        [self.emotionBtn setImage:[UIImage imageNamed:@"compose_keyboardbutton_background"] forState:UIControlStateNormal];
        [self.emotionBtn setImage:[UIImage imageNamed:@"compose_keyboardbutton_background_highlighted"] forState:UIControlStateHighlighted];
    }
}

/** 创建一个按钮 */
- (UIButton *)setupBtn:(NSString *)image highImage:(NSString *)highImage type:(NRComposeToolBarButtonType)type{
    UIButton *btn = [UIButton new];
    
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag = type;
    [self addSubview:btn];
    return btn;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    NSInteger count = self.subviews.count;
    CGFloat btnW = self.width / count;
    CGFloat btnH = self.height;
    for (int i = 0; i < count; i++) {
        UIButton *btn = self.subviews[i];
        btn.y = 0;
        btn.x = i * btnW;
        btn.width = btnW;
        btn.height = btnH;
        
    }
}

- (void)btnClick:(UIButton *)btn{
    if ([self.delegate respondsToSelector:@selector(composeToolBar:didClickButton:)]) {
            [self.delegate composeToolBar:self didClickButton:btn.tag];
    }
}

@end
