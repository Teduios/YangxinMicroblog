//
//  NRDropdownMenu.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/2.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NRDropdownMenu;
@protocol NRDropdownMenuDelegate <NSObject>
@optional

- (void)dropdownMenuDidDismiss:(NRDropdownMenu *)menu;
- (void)dropdownMenuDidShow:(NRDropdownMenu *)menu;


@end


@interface NRDropdownMenu : UIView
@property(nonatomic, weak) id<NRDropdownMenuDelegate> delegate;

+ (instancetype)menu;

- (void)showFromView:(UIView *)fromView;

- (void)dismiss;

/**
 *  下拉菜单的内容
 */
@property(nonatomic, strong) UIView *content;

/**
 *  内容控制器
 */
@property(nonatomic, strong) UIViewController *contentController;
@end
