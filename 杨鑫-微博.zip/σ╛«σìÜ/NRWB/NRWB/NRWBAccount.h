//
//  NRWBAccount.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/6.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NRWBAccount : NSObject <NSCoding>
/** string 用于调用access_token，接口获取授权后的access token*/
@property(nonatomic, strong) NSString *access_token;

/** string access_token的生命周期，单位是秒 */
@property(nonatomic, strong) NSNumber *expires_in;

//@property(nonatomic, strong) NSString *remind_in;

/** string 当前授权用户UID*/
@property(nonatomic, strong) NSString *uid;

/** 账号存储时间 */
@property(nonatomic, strong) NSDate *createdTime;

/** 用户的你昵称 */
@property(nonatomic, strong) NSString *name;
+ (instancetype)accessWithDict:(NSDictionary *)dic;

@end
