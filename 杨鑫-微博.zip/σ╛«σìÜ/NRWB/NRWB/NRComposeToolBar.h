//
//  NRComposeToolBar.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/18.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NRComposeToolBar;

typedef NS_ENUM(NSUInteger, NRComposeToolBarButtonType) {
    NRComposeToolBarButtonTypeCamera, //相机
    NRComposeToolBarButtonTypePicture,//相册
    NRComposeToolBarButtonTypeMention,//@某人
    NRComposeToolBarButtonTypeTrend,  //#
    NRComposeToolBarButtonTypeEmotion //表情
};

@protocol NRComposeToolBarDelegate <NSObject>
@optional
- (void)composeToolBar:(NRComposeToolBar *)toolBar didClickButton:(NRComposeToolBarButtonType)type;
@end

@interface NRComposeToolBar : UIView
@property(nonatomic, weak) id<NRComposeToolBarDelegate> delegate;

/** 是否显示表情按钮 */
@property(nonatomic) BOOL showEmotionButton;
@end
