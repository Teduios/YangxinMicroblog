//
//  NRWBAccountTool.h
//  NRWB
//
//  Created by apple-jd42 on 15/11/6.
//  Copyright © 2015年 NRYX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NRWBAccount.h"

//处理账号相关的所有操作：存储、取出、验证
@interface NRWBAccountTool : NSObject

/**
 *  存储账号信息 
 *
 *  @param account 账号模型
 */
+ (void)saveAccount:(NRWBAccount *)account;

/**
 *  返回账号信息
 *
 *  @return 账号模型，如果账号过期返回nil
 */
+ (NRWBAccount *)account;

@end
